/**
 * PlantDiagram2D.ts
 * Multi-Sheet Interactive 2D Process Flow Diagram (PFD) Suite
 * 
 * Blueprints supported:
 * 1. DWG NO. 6112P 100-100-00: GAS REFORM SECTION
 * 2. DWG NO. 6112P 100-200-00: CO2 REMOVAL SECTION (CATACARB)
 * 3. DWG NO. 6112P 100-300-00: COMPRESSION SECTION (K-301 / K-302 / K-303)
 * 4. DWG NO. 6112P 300-401/402: SYNTHESIS & REFRIGERATION SECTION (R-401 / K-401)
 * 
 * Project: M.O.I. IRAQ - FERTILIZER PROJECT, KHOR AL-ZUBAIR PHASE-1
 * AMMONIA UNIT 
 */

import { PFDStreamData, PFDEquipment, PFDSheetInfo } from './types';
import { SHEET_REFORM_100_INFO, STREAMS_REFORM_100, EQUIPMENT_REFORM_100 } from './data_reform_100';
import { SHEET_CO2_200_INFO, STREAMS_CO2_200, EQUIPMENT_CO2_200 } from './data_co2_200';
import { SHEET_COMP_300_INFO, STREAMS_COMP_300, EQUIPMENT_COMP_300 } from './data_comp_300';
import { SHEET_SYNTH_400_INFO, STREAMS_SYNTH_400, EQUIPMENT_SYNTH_400 } from './data_synth_400';
import { SHEET_UREA_500_INFO, STREAMS_UREA_500, EQUIPMENT_UREA_500 } from './data_urea_500';
import { SHEET_STEAM_BFW_INFO, STREAMS_STEAM_BFW, EQUIPMENT_STEAM_BFW } from './data_steam_bfw';
import { SHEET_STEAM_HEADER_INFO, STREAMS_STEAM_HEADER, EQUIPMENT_STEAM_HEADER } from './data_steam_header';
import { renderCompression300SVG } from './render_comp_300_svg';
import { renderSynthesis400SVG } from './render_synth_400_svg';
import { renderUrea500SVG } from './render_urea_500_svg';
import { renderSteamBFWSVG } from './render_steam_bfw_svg';
import { renderSteamHeaderSVG } from './render_steam_header_svg';

export interface DCSControllerLoop {
  tag: string;
  name: string;
  nameAr: string;
  unit: string;
  pv: number;
  sp: number;
  mv: number;
  mode: 'AUTO' | 'MAN' | 'CAS';
  min: number;
  max: number;
  hh: number;
  h: number;
  l: number;
  ll: number;
  sheetId: 'reform_100' | 'co2_200' | 'comp_300' | 'synth_400' | 'urea_500' | 'steam_bfw' | 'steam_header';
  descAr: string;
}

export const DCS_LOOPS: Record<string, DCSControllerLoop> = {
  'PIC-001': { tag: 'PIC-001', name: 'NG Feed Header Pressure Controller', nameAr: 'متحكم ضغط مجمع استلام الغاز الطبيعي', unit: 'kg/cm²G', pv: 45.0, sp: 45.0, mv: 62.4, mode: 'AUTO', min: 0, max: 60, hh: 52, h: 48, l: 38, ll: 30, sheetId: 'reform_100', descAr: 'ضبط ضغط الغاز القادم من الأنبوب الرئيسي وتأمين ضغط مستقر للمجمع.' },
  'PIC-101': { tag: 'PIC-101', name: 'NG Compressor K-303 Suction Controller', nameAr: 'متحكم ضغط سحب وتدوير ضاغط الغاز K-303', unit: 'kg/cm²G', pv: 19.0, sp: 19.0, mv: 45.2, mode: 'AUTO', min: 0, max: 30, hh: 24, h: 22, l: 17, ll: 15, sheetId: 'reform_100', descAr: 'صمام تدوير وتخفيض الضغط لمنع حدوث ظاهرة الاندفاع Surge في كباس K-303.' },
  'TIC-101': { tag: 'TIC-101', name: 'Fired Preheater H-101 Temp Controller', nameAr: 'متحكم حرارة مخرج مسخن الغاز H-101', unit: '°C', pv: 380.0, sp: 380.0, mv: 58.0, mode: 'AUTO', min: 0, max: 500, hh: 410, h: 395, l: 360, ll: 340, sheetId: 'reform_100', descAr: 'تأمين حرارة 380°C المثالية لتنشيط محفز إزالة الكبريت Co-Mo و ZnO.' },
  'FRC-103': { tag: 'FRC-103', name: 'Process Steam Feed Flow Controller', nameAr: 'متحكم تدفق بخار العملية للمصلح الأولي', unit: 't/h', pv: 104.5, sp: 104.5, mv: 71.0, mode: 'CAS', min: 0, max: 150, hh: 135, h: 120, l: 80, ll: 60, sheetId: 'reform_100', descAr: 'التحكم بنسبة البخار إلى الكربون (Steam to Carbon Ratio S/C = 3.20).' },
  'FRC-105': { tag: 'FRC-105', name: 'Natural Gas Process Feed Flow Controller', nameAr: 'متحكم تدفق الغاز الطبيعي لفرن الإصلاح', unit: 't/h', pv: 34.5, sp: 34.5, mv: 68.5, mode: 'AUTO', min: 0, max: 50, hh: 45, h: 40, l: 25, ll: 18, sheetId: 'reform_100', descAr: 'معدل التغذية الهيدروكربونية الأساسية لإنتاج غاز التخليق.' },
  'TIC-102': { tag: 'TIC-102', name: 'Primary Reformer Radiant Outlet Temp', nameAr: 'متحكم حرارة مخرج أنابيب فرن الإصلاح R-101', unit: '°C', pv: 750.0, sp: 750.0, mv: 78.5, mode: 'AUTO', min: 500, max: 900, hh: 820, h: 780, l: 710, ll: 680, sheetId: 'reform_100', descAr: 'ضبط احتراق المشاعل في فرن الإصلاح الأولي لتحقيق أقصى تحويل للميثان.' },
  'FRCA-107': { tag: 'FRCA-107', name: 'Process Air Flow to Secondary Reformer', nameAr: 'متحكم تدفق الهواء المضغوط للمصلح الثانوي R-103', unit: 't/h', pv: 48.2, sp: 48.2, mv: 64.0, mode: 'CAS', min: 0, max: 80, hh: 70, h: 60, l: 35, ll: 25, sheetId: 'reform_100', descAr: 'تأمين النتروجين بالنسب المتكافئة N2:H2 = 1:3 ورفع الحرارة إلى 900°C.' },
  'TIC-104': { tag: 'TIC-104', name: 'HTS Shift Reactor R-104 Outlet Temp', nameAr: 'متحكم حرارة مفاعل التحويل العالي HTS', unit: '°C', pv: 390.0, sp: 390.0, mv: 52.0, mode: 'AUTO', min: 200, max: 500, hh: 440, h: 415, l: 350, ll: 320, sheetId: 'reform_100', descAr: 'أكسدة أول أكسيد الكربون CO + H2O -> CO2 + H2 فوق محفز Fe-Cr.' },
  'TIC-105': { tag: 'TIC-105', name: 'LTS Shift Reactor R-105 Outlet Temp', nameAr: 'متحكم حرارة مفاعل التحويل الواطئ LTS', unit: '°C', pv: 220.0, sp: 220.0, mv: 48.0, mode: 'AUTO', min: 150, max: 300, hh: 250, h: 235, l: 195, ll: 180, sheetId: 'reform_100', descAr: 'خفض نسبة CO إلى أقل من 0.3% فوق محفز Cu-Zn-Al.' },
  'TIC-106': { tag: 'TIC-106', name: 'Methanator R-106 Peak Bed Temp', nameAr: 'متحكم حرارة طبقة مفاعل الميثانايتر R-106', unit: '°C', pv: 295.0, sp: 295.0, mv: 54.0, mode: 'AUTO', min: 200, max: 400, hh: 350, h: 320, l: 260, ll: 240, sheetId: 'reform_100', descAr: 'تحويل بقايا أكاسيد الكربون السامة لمحفز الأمونيا إلى ميثان خامل (< 5 ppm).' },
  'LIC-201': { tag: 'LIC-201', name: 'Catacarb Absorber T-201 Sump Level', nameAr: 'متحكم مستوى قعر برج الامتصاص T-201', unit: '%', pv: 55.0, sp: 55.0, mv: 55.0, mode: 'AUTO', min: 0, max: 100, hh: 85, h: 75, l: 30, ll: 15, sheetId: 'co2_200', descAr: 'تنظيم تدفق المحلول الغني Rich Solution إلى توربين الاسترجاع وبرج التجريد.' },
  'TIC-201': { tag: 'TIC-201', name: 'Regenerator T-202 Reboiler Temp', nameAr: 'متحكم حرارة مرجل إعادة غلي كاتاكارب E-201', unit: '°C', pv: 125.0, sp: 125.0, mv: 63.0, mode: 'AUTO', min: 80, max: 160, hh: 140, h: 132, l: 115, ll: 105, sheetId: 'co2_200', descAr: 'تجريد غاز CO2 من محلول كربونات البوتاسيوم بواسطة الحرارة والبخار.' },
  'PIC-301': { tag: 'PIC-301', name: 'Syngas Compressor K-301 Suction Press', nameAr: 'متحكم ضغط سحب ضاغط غاز التخليق K-301', unit: 'kg/cm²G', pv: 25.5, sp: 25.5, mv: 50.0, mode: 'AUTO', min: 0, max: 40, hh: 32, h: 28, l: 20, ll: 16, sheetId: 'comp_300', descAr: 'المحافظة على ثبات ضغط سحب المرحلة الأولى لضاغط K-301.' },
  'SIC-301': { tag: 'SIC-301', name: 'Steam Turbine K-301T Speed Controller', nameAr: 'متحكم سرعة توربين ضاغط غاز التخليق K-301T', unit: 'RPM', pv: 10850, sp: 10850, mv: 74.0, mode: 'AUTO', min: 0, max: 13000, hh: 11800, h: 11200, l: 9500, ll: 8500, sheetId: 'comp_300', descAr: 'حاكم السرعة الهيدروليكي Electronic Governor لتوربين البخار عالي الضغط.' },
  'PIC-401': { tag: 'PIC-401', name: 'Ammonia Synthesis Loop Pressure', nameAr: 'متحكم ضغط حلقة تخليق الأمونيا R-401', unit: 'kg/cm²G', pv: 215.0, sp: 215.0, mv: 80.0, mode: 'AUTO', min: 0, max: 300, hh: 245, h: 230, l: 180, ll: 150, sheetId: 'synth_400', descAr: 'ضغط تخليق الأمونيا N2 + 3H2 <=> 2NH3 عند 215 بار.' },
  'TIC-401': { tag: 'TIC-401', name: 'R-401 Bed 1 Inlet Temp Controller', nameAr: 'متحكم حرارة مدخل الطبقة الأولى لمفاعل R-401', unit: '°C', pv: 185.0, sp: 185.0, mv: 42.0, mode: 'AUTO', min: 100, max: 300, hh: 230, h: 205, l: 165, ll: 150, sheetId: 'synth_400', descAr: 'ضبط صمام التجاوز البارد Cold Bypass لبدء التفاعل فوق محفز الحديد المنشط.' },
  'TIC-402': { tag: 'TIC-402', name: 'R-401 Bed 2 Peak Temp Controller', nameAr: 'حرارة قمة التفاعل في الطبقة الثانية R-401', unit: '°C', pv: 440.0, sp: 440.0, mv: 55.0, mode: 'AUTO', min: 300, max: 550, hh: 510, h: 475, l: 400, ll: 370, sheetId: 'synth_400', descAr: 'مراقبة أقصى حرارة تفاعل طارد للحرارة لمنع تلف المحفز والتجويف.' },
  'LIC-401': { tag: 'LIC-401', name: 'Primary Ammonia Separator V-401 Level', nameAr: 'متحكم مستوى عازل الأمونيا الأولي V-401', unit: '%', pv: 50.0, sp: 50.0, mv: 50.0, mode: 'AUTO', min: 0, max: 100, hh: 80, h: 70, l: 30, ll: 20, sheetId: 'synth_400', descAr: 'فصل وتصريف الأمونيا السائلة المنتجة عند 40°C وتوجيهها للمستودعات.' },
  'TIC-406': { tag: 'TIC-406', name: 'Secondary Chiller E-406 Refrigerant Temp', nameAr: 'متحكم حرارة مبرد الأمونيا العميق E-406', unit: '°C', pv: 2.0, sp: 2.0, mv: 68.0, mode: 'AUTO', min: -10, max: 25, hh: 15, h: 8, l: -2, ll: -8, sheetId: 'synth_400', descAr: 'تبريد الغاز بالتمدد إلى 2°C لرفع كفاءة تكثيف وفصل الأمونيا.' },
  'PIC-501': { tag: 'PIC-501', name: 'Urea Reactor R-501 Pressure Controller', nameAr: 'متحكم ضغط مفاعل تصنيع اليوريا R-501', unit: 'kg/cm²G', pv: 155.0, sp: 155.0, mv: 72.0, mode: 'AUTO', min: 0, max: 200, hh: 175, h: 165, l: 135, ll: 120, sheetId: 'urea_500', descAr: 'تفاعل الأمونيا السائلة وثاني أكسيد الكربون لإنتاج كاربامات الأمونيوم واليوريا.' },
  'TIC-501': { tag: 'TIC-501', name: 'Urea Reactor R-501 Temperature', nameAr: 'متحكم حرارة تفاعل اليوريا R-501', unit: '°C', pv: 188.0, sp: 188.0, mv: 60.0, mode: 'AUTO', min: 100, max: 250, hh: 205, h: 195, l: 175, ll: 160, sheetId: 'urea_500', descAr: 'تأمين حرارة 188°C لتحقيق التوازن الثرموديناميكي الأمثل لتحويل الكاربامات.' },
  'LIC-102': { tag: 'LIC-102', name: 'HP Steam Drum V-102 Water Level', nameAr: 'متحكم مستوى ماء مرجل البخار عالي الضغط V-102', unit: '%', pv: 50.0, sp: 50.0, mv: 50.0, mode: 'AUTO', min: 0, max: 100, hh: 75, h: 65, l: 35, ll: 25, sheetId: 'steam_bfw', descAr: 'تحكم ثلاثي العناصر (3-Element Control: Level + Steam Flow + BFW Flow).' },
  'PIC-165': { tag: 'PIC-165', name: 'S-65 Superheated Steam Header Press', nameAr: 'متحكم ضغط مجمع البخار العالي S-65', unit: 'kg/cm²G', pv: 65.0, sp: 65.0, mv: 58.0, mode: 'AUTO', min: 0, max: 90, hh: 78, h: 72, l: 56, ll: 50, sheetId: 'steam_header', descAr: 'مجمع التغذية الرئيسي لتوربينات ضواغط K-301 و K-302 ومحطات التخفيض.' },
  'PIC-139': { tag: 'PIC-139', name: 'S-39 Medium Pressure Steam Header', nameAr: 'متحكم ضغط مجمع البخار المتوسط S-39', unit: 'kg/cm²G', pv: 39.0, sp: 39.0, mv: 62.0, mode: 'AUTO', min: 0, max: 60, hh: 48, h: 44, l: 32, ll: 26, sheetId: 'steam_header', descAr: 'تغذية بخار التفاعل للمصلح الأولي R-101 وتوربين ضاغط K-303.' },
  'PIC-112': { tag: 'PIC-112', name: 'S-12 Low Pressure Steam Header', nameAr: 'متحكم ضغط مجمع البخار المنخفض S-12', unit: 'kg/cm²G', pv: 12.0, sp: 12.0, mv: 44.0, mode: 'AUTO', min: 0, max: 25, hh: 18, h: 15, l: 9, ll: 6, sheetId: 'steam_header', descAr: 'تغذية مراجل إعادة غلي كاتاكارب E-201 ومسخنات إزالة الغازات.' },
  'PIC-103': { tag: 'PIC-103', name: 'S-3 Deaerator LP Steam Header', nameAr: 'متحكم ضغط مجمع بخار نازع الغازات S-3', unit: 'kg/cm²G', pv: 3.2, sp: 3.2, mv: 40.0, mode: 'AUTO', min: 0, max: 10, hh: 6.0, h: 4.5, l: 2.2, ll: 1.5, sheetId: 'steam_header', descAr: 'تأمين بخار التجريد الحراري لنازع الأكسجين والغازات V-103 عند 125°C.' }
};

export class PlantDiagram2D {
  private container: HTMLElement | null = null;
  private svgElem: SVGSVGElement | null = null;
  private zoomGroup: SVGGElement | null = null;
  private currentSheet: 'reform_100' | 'co2_200' | 'comp_300' | 'synth_400' | 'urea_500' | 'steam_bfw' | 'steam_header' = 'steam_header';
  
  private scale = 0.95;
  private panX = 0;
  private panY = 0;
  private isDragging = false;
  private dragMoved = false;
  private startMouseX = 0;
  private startMouseY = 0;
  private startDragX = 0;
  private startDragY = 0;
  private isLocked = false;
  private isDcsSidebarOpen = true;

  private selectedItem: string | null = null;
  private activeFaceplateTag: string | null = null;
  private faceplateInterval: any = null;
  private showParticles = true;
  private activeFilter = 'all';

  public getSheetInfo(): PFDSheetInfo {
    if (this.currentSheet === 'steam_header') return SHEET_STEAM_HEADER_INFO;
    if (this.currentSheet === 'steam_bfw') return SHEET_STEAM_BFW_INFO;
    if (this.currentSheet === 'urea_500') return SHEET_UREA_500_INFO;
    if (this.currentSheet === 'synth_400') return SHEET_SYNTH_400_INFO;
    if (this.currentSheet === 'comp_300') return SHEET_COMP_300_INFO;
    if (this.currentSheet === 'co2_200') return SHEET_CO2_200_INFO;
    return SHEET_REFORM_100_INFO;
  }

  public getStreams(): Record<number, PFDStreamData> {
    if (this.currentSheet === 'steam_header') return STREAMS_STEAM_HEADER;
    if (this.currentSheet === 'steam_bfw') return STREAMS_STEAM_BFW;
    if (this.currentSheet === 'urea_500') return STREAMS_UREA_500;
    if (this.currentSheet === 'synth_400') return STREAMS_SYNTH_400;
    if (this.currentSheet === 'comp_300') return STREAMS_COMP_300;
    if (this.currentSheet === 'co2_200') return STREAMS_CO2_200;
    return STREAMS_REFORM_100;
  }

  public getEquipment(): Record<string, PFDEquipment> {
    if (this.currentSheet === 'steam_header') return EQUIPMENT_STEAM_HEADER;
    if (this.currentSheet === 'steam_bfw') return EQUIPMENT_STEAM_BFW;
    if (this.currentSheet === 'urea_500') return EQUIPMENT_UREA_500;
    if (this.currentSheet === 'synth_400') return EQUIPMENT_SYNTH_400;
    if (this.currentSheet === 'comp_300') return EQUIPMENT_COMP_300;
    if (this.currentSheet === 'co2_200') return EQUIPMENT_CO2_200;
    return EQUIPMENT_REFORM_100;
  }

  public init(container: HTMLElement) {
    this.container = container;
    this.render();
  }

  public switchSheet(sheetId: 'reform_100' | 'co2_200' | 'comp_300' | 'synth_400' | 'urea_500' | 'steam_bfw' | 'steam_header') {
    this.currentSheet = sheetId;
    this.activeFilter = 'all';
    this.selectedItem = null;
    this.scale = 0.95;
    this.panX = 0;
    this.panY = 0;
    this.render();
  }

  public render() {
    if (!this.container) return;
    const sheet = this.getSheetInfo();
    const equipment = this.getEquipment();
    const eqKeys = Object.keys(equipment);
    const sheetLoops = Object.values(DCS_LOOPS).filter(l => l.sheetId === this.currentSheet);

    this.container.innerHTML = `
      <div class="pfd-root-container">
        <!-- TOP INDUSTRIAL DCS STATUS & KPI RIBBON -->
        <div class="dcs-kpi-ribbon">
          <div class="dcs-kpi-badge">
            <span class="dcs-led-pulse"></span>
            <span>DCS: CENTUM-VP ONLINE (AMM-PH1)</span>
          </div>
          <div class="dcs-kpi-item">
            <span class="dcs-kpi-label">حمولة المصنع (PLANT LOAD):</span>
            <span class="dcs-kpi-val highlight">100.0% DESIGN</span>
          </div>
          <div class="dcs-kpi-item">
            <span class="dcs-kpi-label">الغاز الطبيعي (NG FEED):</span>
            <span class="dcs-kpi-val">34.5 t/h @ 45 kg/cm²</span>
          </div>
          <div class="dcs-kpi-item">
            <span class="dcs-kpi-label">نسبة البخار (S/C RATIO):</span>
            <span class="dcs-kpi-val" style="color:#38bdf8;">3.20 (OPTIMUM)</span>
          </div>
          <div class="dcs-kpi-item">
            <span class="dcs-kpi-label">حلقة التخليق (SYNTH LOOP):</span>
            <span class="dcs-kpi-val" style="color:#00e5aa;">215 kg/cm²G | 440°C</span>
          </div>
          <div class="dcs-kpi-item">
            <span class="dcs-kpi-label">إنتاج الأمونيا (NH3 RATE):</span>
            <span class="dcs-kpi-val" style="color:#c084fc;">41.67 t/h (1,000 MTPD)</span>
          </div>
          <div class="dcs-kpi-item">
            <span class="dcs-kpi-label">إنتاج اليوريا (UREA RATE):</span>
            <span class="dcs-kpi-val" style="color:#fbbf24;">72.9 t/h (1,750 MTPD)</span>
          </div>
          <div class="dcs-kpi-item">
            <span class="dcs-kpi-label">البخار العالي (HP STEAM S-65):</span>
            <span class="dcs-kpi-val" style="color:#f97316;">210 t/h @ 65 kg/cm² 435°C</span>
          </div>
        </div>

        <!-- DCS Navigation & Header Toolbar -->
        <div class="pfd-header-bar">
          <div class="pfd-title-group">
            <button id="pfd-btn-toggle-dcs-sidebar" class="dcs-toggle-sb-btn" title="إظهار/إخفاء لوحة التحكم والأقسام الجانبية">
              <span>🎛</span>
              <span>لوحة الأقسام DCS</span>
            </button>
            <div class="pfd-badge">${sheet.dwgNo}</div>
            <div>
              <div class="pfd-main-title">${sheet.title}</div>
              <div class="pfd-sub-title">${sheet.titleAr} | ${sheet.customer}</div>
            </div>
          </div>

          <!-- Section Sub-filters -->
          <div class="pfd-filter-tabs">
            ${sheet.filters.map(f => `
              <button class="pfd-ftab ${this.activeFilter === f.id ? 'active' : ''}" data-sec="${f.id}">
                ${f.labelAr}
              </button>
            `).join('')}
          </div>

          <!-- Action & Canvas Controls -->
          <div class="pfd-actions-group">
            <button id="pfd-btn-lock" class="pfd-btn ${this.isLocked ? 'dcs-btn-locked' : ''}" title="قفل / فتح تحريك اللوحة لتثبيت العرض التام">
              <span>${this.isLocked ? '🔒' : '🔓'}</span>
              <span>${this.isLocked ? 'اللوحة مقفلة (ثابتة)' : 'قفل اللوحة'}</span>
            </button>

            <button id="pfd-btn-zoom-reset" class="pfd-btn" title="تثبيت وملاءمة وتوسيط اللوحة بالكامل">
              <span>🎯</span> ملاءمة وتوسيط
            </button>

            <button id="pfd-btn-stream-table" class="pfd-btn" title="عرض جدول موازنة المواد والغازات">
              <span>📊</span> جدول المسارات
            </button>

            <button id="pfd-btn-anim" class="pfd-btn" title="تشغيل / إيقاف جريان الخطوط">
              <span>⚡</span> ${this.showParticles ? 'إيقاف الحركة' : 'تشغيل الحركة'}
            </button>

            <button id="pfd-btn-zoom-in" class="pfd-btn" title="تكبير">+</button>
            <button id="pfd-btn-zoom-out" class="pfd-btn" title="تصغير">-</button>

            <button id="pfd-btn-exit" class="pfd-btn pfd-btn-close" title="العودة لشاشة التحكم">
              <span>✕</span> خروج
            </button>
          </div>
        </div>

        <!-- WORKSPACE VIEWPORT -->
        <div class="pfd-workspace-viewport">
          <!-- DCS INTEGRATED LEFT NAVIGATION SIDEBAR -->
          <div id="dcsSectionSidebar" class="dcs-section-sidebar ${this.isDcsSidebarOpen ? 'open' : ''}">
            <div class="dcs-sb-header">
              <div class="dcs-sb-title">
                <span>📑</span>
                <span>أقسام مجمع الأمونيا (PFD 6112P)</span>
              </div>
              <button id="dcs-sb-close-btn" class="dcs-sb-close" title="إغلاق اللوحة الجانبية">✕</button>
            </div>

            <!-- 1. Blueprint Sheets List -->
            <div class="dcs-sb-section">
              <div class="dcs-sb-sec-label">المخططات الهندسية السبعة (7 Process Sheets)</div>
              <div class="dcs-sheets-list">
                <button class="dcs-sheet-item ${this.currentSheet === 'steam_header' ? 'active' : ''}" data-sheet="steam_header">
                  <div class="dcs-sheet-icon">♨️</div>
                  <div class="dcs-sheet-info">
                    <div class="dcs-sheet-code">DWG 6112P-100-104</div>
                    <div class="dcs-sheet-name">مجمعات البخار ومحطات التخفيض (Steam Headers)</div>
                  </div>
                  <span class="dcs-tag-badge">S-65/39/12/3</span>
                </button>

                <button class="dcs-sheet-item ${this.currentSheet === 'steam_bfw' ? 'active' : ''}" data-sheet="steam_bfw">
                  <div class="dcs-sheet-icon">💧</div>
                  <div class="dcs-sheet-info">
                    <div class="dcs-sheet-code">DWG 6112P-100-103</div>
                    <div class="dcs-sheet-name">مياه المراجل وتوليد البخار (BFW & Steam Drum)</div>
                  </div>
                  <span class="dcs-tag-badge">V-102/V-103</span>
                </button>

                <button class="dcs-sheet-item ${this.currentSheet === 'urea_500' ? 'active' : ''}" data-sheet="urea_500">
                  <div class="dcs-sheet-icon">🌾</div>
                  <div class="dcs-sheet-info">
                    <div class="dcs-sheet-code">DWG 6112P-100-501</div>
                    <div class="dcs-sheet-name">إنتاج وتحبيب اليوريا (Urea Synthesis & Prilling)</div>
                  </div>
                  <span class="dcs-tag-badge">R-501/T-571</span>
                </button>

                <button class="dcs-sheet-item ${this.currentSheet === 'synth_400' ? 'active' : ''}" data-sheet="synth_400">
                  <div class="dcs-sheet-icon">💠</div>
                  <div class="dcs-sheet-info">
                    <div class="dcs-sheet-code">DWG 6112P-300-400</div>
                    <div class="dcs-sheet-name">تخليق وتبريد الأمونيا (NH3 Synthesis & Chilling)</div>
                  </div>
                  <span class="dcs-tag-badge">R-401/K-401</span>
                </button>

                <button class="dcs-sheet-item ${this.currentSheet === 'comp_300' ? 'active' : ''}" data-sheet="comp_300">
                  <div class="dcs-sheet-icon">⚙️</div>
                  <div class="dcs-sheet-info">
                    <div class="dcs-sheet-code">DWG 6112P-100-300</div>
                    <div class="dcs-sheet-name">ضواغط الغاز والهواء (Compression K-301/302/303)</div>
                  </div>
                  <span class="dcs-tag-badge">K-301/2/3</span>
                </button>

                <button class="dcs-sheet-item ${this.currentSheet === 'co2_200' ? 'active' : ''}" data-sheet="co2_200">
                  <div class="dcs-sheet-icon">🧪</div>
                  <div class="dcs-sheet-info">
                    <div class="dcs-sheet-code">DWG 6112P-100-200</div>
                    <div class="dcs-sheet-name">إزالة واستخلاص CO₂ كاتاكارب (Catacarb Removal)</div>
                  </div>
                  <span class="dcs-tag-badge">T-201/T-202</span>
                </button>

                <button class="dcs-sheet-item ${this.currentSheet === 'reform_100' ? 'active' : ''}" data-sheet="reform_100">
                  <div class="dcs-sheet-icon">🔥</div>
                  <div class="dcs-sheet-info">
                    <div class="dcs-sheet-code">DWG 6112P-100-100</div>
                    <div class="dcs-sheet-name">تحويل الغاز والإصلاح والميثانايتر (Reforming & Shift)</div>
                  </div>
                  <span class="dcs-tag-badge">R-101/3/4/5/6</span>
                </button>
              </div>
            </div>

            <!-- 2. Active Sheet Equipment List -->
            <div class="dcs-sb-section">
              <div class="dcs-sb-sec-label">معدات المخطط النشط (${eqKeys.length} معدة)</div>
              <div class="dcs-eq-quick-list">
                ${eqKeys.map(k => {
                  const eq = equipment[k];
                  return `
                    <div class="dcs-eq-pill" data-eq="${eq.tag}" title="${eq.nameAr} - انقر للتركيز والمواصفات">
                      <span class="dcs-eq-tag">${eq.tag}</span>
                      <span class="dcs-eq-name">${eq.nameAr}</span>
                    </div>
                  `;
                }).join('')}
              </div>
            </div>

            <!-- 3. Active Sheet PID Control Loops (DCS Faceplates) -->
            <div class="dcs-sb-section">
              <div class="dcs-sb-sec-label">أجهزة وحلقات التحكم DCS (${sheetLoops.length} حلقة PID)</div>
              <div class="dcs-loops-quick-list">
                ${sheetLoops.map(loop => `
                  <div class="dcs-loop-pill" data-loop="${loop.tag}" title="انقر لفتح لوحة تحكم DCS Faceplate">
                    <div style="display:flex;justify-content:space-between;align-items:center;">
                      <span class="dcs-loop-tag">${loop.tag}</span>
                      <span class="dcs-loop-mode">${loop.mode}</span>
                    </div>
                    <div class="dcs-loop-desc">${loop.nameAr}</div>
                    <div class="dcs-loop-readout">
                      <span>PV: <b>${loop.pv}</b> ${loop.unit}</span>
                      <span>SP: <b>${loop.sp}</b></span>
                    </div>
                  </div>
                `).join('')}
              </div>
            </div>
          </div>

          <!-- SVG Canvas Container -->
          <div class="pfd-canvas-wrapper ${this.isLocked ? 'locked-canvas' : ''}" id="pfdCanvasWrapper">
            ${this.isLocked ? `
              <div class="dcs-canvas-lock-badge">
                <span>🔒</span> اللوحة مثبتة بالكامل ومقفلة (Canvas Locked)
              </div>
            ` : ''}

            <svg id="pfdSvg" class="pfd-svg-element" viewBox="0 0 2300 1150" preserveAspectRatio="xMidYMid meet">
              <defs>
                <!-- 3D Realistic Metallic Vertical Cylinder Gradient -->
                <linearGradient id="pfdSteelGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stop-color="#94a3b8"/>
                  <stop offset="12%" stop-color="#cbd5e1"/>
                  <stop offset="32%" stop-color="#f8fafc"/>
                  <stop offset="42%" stop-color="#ffffff"/>
                  <stop offset="68%" stop-color="#e2e8f0"/>
                  <stop offset="88%" stop-color="#cbd5e1"/>
                  <stop offset="100%" stop-color="#64748b"/>
                </linearGradient>

                <!-- 3D Realistic Metallic Horizontal Cylinder Gradient -->
                <linearGradient id="pfdSteelHorizGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stop-color="#94a3b8"/>
                  <stop offset="15%" stop-color="#cbd5e1"/>
                  <stop offset="32%" stop-color="#f8fafc"/>
                  <stop offset="40%" stop-color="#ffffff"/>
                  <stop offset="70%" stop-color="#e2e8f0"/>
                  <stop offset="90%" stop-color="#cbd5e1"/>
                  <stop offset="100%" stop-color="#64748b"/>
                </linearGradient>

                <!-- Dished Head Radial Metallic Top -->
                <linearGradient id="pfdDishTopGrad" x1="0%" y1="100%" x2="0%" y2="0%">
                  <stop offset="0%" stop-color="#cbd5e1"/>
                  <stop offset="50%" stop-color="#ffffff"/>
                  <stop offset="100%" stop-color="#94a3b8"/>
                </linearGradient>

                <!-- Dished Head Radial Metallic Bottom -->
                <linearGradient id="pfdDishBotGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stop-color="#cbd5e1"/>
                  <stop offset="50%" stop-color="#94a3b8"/>
                  <stop offset="100%" stop-color="#64748b"/>
                </linearGradient>

                <!-- Heavy Base Skirt / Saddle Gradient -->
                <linearGradient id="pfdSkirtGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stop-color="#475569"/>
                  <stop offset="25%" stop-color="#64748b"/>
                  <stop offset="50%" stop-color="#94a3b8"/>
                  <stop offset="75%" stop-color="#64748b"/>
                  <stop offset="100%" stop-color="#334155"/>
                </linearGradient>

                <!-- 3D Turbomachinery Conical / Compressor Housing Gradient -->
                <linearGradient id="pfdTurbineGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stop-color="#64748b"/>
                  <stop offset="20%" stop-color="#94a3b8"/>
                  <stop offset="45%" stop-color="#ffffff"/>
                  <stop offset="75%" stop-color="#cbd5e1"/>
                  <stop offset="100%" stop-color="#475569"/>
                </linearGradient>

                <!-- Motor & Drive Casing Gradient -->
                <linearGradient id="pfdMotorGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stop-color="#334155"/>
                  <stop offset="30%" stop-color="#64748b"/>
                  <stop offset="50%" stop-color="#94a3b8"/>
                  <stop offset="70%" stop-color="#475569"/>
                  <stop offset="100%" stop-color="#1e293b"/>
                </linearGradient>

                <!-- Heat Exchanger Tube Bundle / Shell Gradient -->
                <linearGradient id="pfdExchangerShellGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stop-color="#94a3b8"/>
                  <stop offset="20%" stop-color="#f1f5f9"/>
                  <stop offset="40%" stop-color="#ffffff"/>
                  <stop offset="75%" stop-color="#cbd5e1"/>
                  <stop offset="100%" stop-color="#64748b"/>
                </linearGradient>

                <!-- Radiant Furnace Fire Gradient -->
                <linearGradient id="pfdFireGrad" x1="0%" y1="100%" x2="0%" y2="0%">
                  <stop offset="0%" stop-color="#7f1d1d"/>
                  <stop offset="20%" stop-color="#dc2626"/>
                  <stop offset="50%" stop-color="#ea580c"/>
                  <stop offset="80%" stop-color="#f59e0b"/>
                  <stop offset="100%" stop-color="#fef08a"/>
                </linearGradient>

                <!-- Furnace Body Cutaway Inner Warm Glow -->
                <linearGradient id="pfdFurnaceInnerGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stop-color="#1e1b4b"/>
                  <stop offset="40%" stop-color="#312e81"/>
                  <stop offset="70%" stop-color="#431407"/>
                  <stop offset="100%" stop-color="#7c2d12"/>
                </linearGradient>

                <!-- Heating Coils Metallic Gradient -->
                <linearGradient id="pfdCoilGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stop-color="#cbd5e1"/>
                  <stop offset="50%" stop-color="#ffffff"/>
                  <stop offset="100%" stop-color="#94a3b8"/>
                </linearGradient>

                <!-- Hyperbolic Cooling Tower Gradient -->
                <linearGradient id="pfdTowerGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stop-color="#64748b"/>
                  <stop offset="20%" stop-color="#cbd5e1"/>
                  <stop offset="45%" stop-color="#f8fafc"/>
                  <stop offset="70%" stop-color="#cbd5e1"/>
                  <stop offset="100%" stop-color="#475569"/>
                </linearGradient>

                <linearGradient id="pfdWaterGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stop-color="#e0f2fe"/>
                  <stop offset="50%" stop-color="#bae6fd"/>
                  <stop offset="100%" stop-color="#38bdf8"/>
                </linearGradient>

                <linearGradient id="pfdCatacarbGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stop-color="#d1fae5"/>
                  <stop offset="50%" stop-color="#a7f3d0"/>
                  <stop offset="100%" stop-color="#6ee7b7"/>
                </linearGradient>

                <!-- Technical Cross-Hatch Wire Mesh Catalyst Packing Pattern -->
                <pattern id="pfdPackingPattern" width="10" height="10" patternUnits="userSpaceOnUse">
                  <path d="M 0 0 L 10 10 M 10 0 L 0 10" fill="none" stroke="#475569" stroke-width="0.75" opacity="0.6"/>
                  <line x1="0" y1="5" x2="10" y2="5" stroke="#94a3b8" stroke-width="0.5" opacity="0.4"/>
                </pattern>

                <!-- Exchanger Tube Lines Pattern -->
                <pattern id="pfdTubePattern" width="12" height="6" patternUnits="userSpaceOnUse">
                  <line x1="0" y1="3" x2="12" y2="3" stroke="#0284c7" stroke-width="1.2"/>
                  <line x1="6" y1="0" x2="6" y2="6" stroke="#94a3b8" stroke-width="0.8" stroke-dasharray="2,2"/>
                </pattern>

                <pattern id="pfdGridPattern" width="40" height="40" patternUnits="userSpaceOnUse">
                  <rect width="40" height="40" fill="#ffffff"/>
                  <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#f1f5f9" stroke-width="0.8"/>
                  <path d="M 200 0 L 0 0 0 200" fill="none" stroke="#e2e8f0" stroke-width="1.2"/>
                </pattern>

                <!-- Realistic Volumetric Equipment Drop Shadow -->
                <filter id="pfdEquipShadow" x="-15%" y="-15%" width="130%" height="130%">
                  <feDropShadow dx="3" dy="5" stdDeviation="4" flood-color="#0f172a" flood-opacity="0.18"/>
                </filter>

                <!-- Process Piping Arrow Markers (Crisp, High-Visibility Real Solid Engineering Arrows) -->
                <marker id="pfdArrow" viewBox="0 0 14 14" refX="10" refY="7" markerWidth="9" markerHeight="9" orient="auto-start-reverse">
                  <polygon points="1 2, 13 7, 1 12, 4 7" fill="#0284c7" stroke="#0f172a" stroke-width="0.8"/>
                </marker>
                <marker id="pfdArrowCyan" viewBox="0 0 14 14" refX="10" refY="7" markerWidth="9" markerHeight="9" orient="auto-start-reverse">
                  <polygon points="1 2, 13 7, 1 12, 4 7" fill="#0284c7" stroke="#0f172a" stroke-width="0.8"/>
                </marker>
                <marker id="pfdArrowYellow" viewBox="0 0 14 14" refX="10" refY="7" markerWidth="9" markerHeight="9" orient="auto-start-reverse">
                  <polygon points="1 2, 13 7, 1 12, 4 7" fill="#d97706" stroke="#0f172a" stroke-width="0.8"/>
                </marker>
                <marker id="pfdArrowGreen" viewBox="0 0 14 14" refX="10" refY="7" markerWidth="9" markerHeight="9" orient="auto-start-reverse">
                  <polygon points="1 2, 13 7, 1 12, 4 7" fill="#16a34a" stroke="#0f172a" stroke-width="0.8"/>
                </marker>
                <marker id="pfdArrowRed" viewBox="0 0 14 14" refX="10" refY="7" markerWidth="9" markerHeight="9" orient="auto-start-reverse">
                  <polygon points="1 2, 13 7, 1 12, 4 7" fill="#dc2626" stroke="#0f172a" stroke-width="0.8"/>
                </marker>
                <marker id="pfdArrowPurple" viewBox="0 0 14 14" refX="10" refY="7" markerWidth="9" markerHeight="9" orient="auto-start-reverse">
                  <polygon points="1 2, 13 7, 1 12, 4 7" fill="#7c3aed" stroke="#0f172a" stroke-width="0.8"/>
                </marker>
                <marker id="pfdArrowSlate" viewBox="0 0 14 14" refX="10" refY="7" markerWidth="9" markerHeight="9" orient="auto-start-reverse">
                  <polygon points="1 2, 13 7, 1 12, 4 7" fill="#334155" stroke="#0f172a" stroke-width="0.8"/>
                </marker>
              </defs>

              <rect width="100%" height="100%" fill="url(#pfdGridPattern)"/>

              <g id="pfdZoomGroup">
                ${this.currentSheet === 'steam_header'
                  ? renderSteamHeaderSVG(this.showParticles)
                  : (this.currentSheet === 'steam_bfw'
                      ? renderSteamBFWSVG(this.showParticles)
                      : (this.currentSheet === 'urea_500'
                          ? renderUrea500SVG(this.showParticles)
                          : (this.currentSheet === 'synth_400'
                              ? renderSynthesis400SVG(this.showParticles)
                              : (this.currentSheet === 'comp_300'
                                  ? renderCompression300SVG(this.showParticles)
                                  : (this.currentSheet === 'co2_200'
                                      ? this.renderCO2Removal200SVG()
                                      : this.renderReform100SVG())))))}
              </g>
            </svg>
          </div>

          <!-- Inspector Sidebar -->
          <div id="pfdInspectorSidebar" class="pfd-inspector-sidebar">
            <div class="pfd-insp-header">
              <span id="pfdInspTag" class="pfd-insp-tag">TAG</span>
              <button id="pfdInspClose" class="pfd-insp-close">✕</button>
            </div>
            <div id="pfdInspTitle" class="pfd-insp-title">Equipment Name</div>
            <div id="pfdInspNameAr" class="pfd-insp-name-ar">الاسم العربي</div>

            <div class="pfd-insp-section">
              <div class="pfd-insp-sec-title">المواصفات الهندسية (Operating Conditions)</div>
              <div id="pfdInspSpecs" class="pfd-spec-grid"></div>
            </div>

            <div class="pfd-insp-section">
              <div class="pfd-insp-sec-title">الوصف والوظيفة التشغيلية</div>
              <p id="pfdInspDesc" class="pfd-insp-desc"></p>
            </div>

            <div class="pfd-insp-section" id="pfdInspConnectedSec">
              <div class="pfd-insp-sec-title">المسارات المرتبطة (Connected Streams)</div>
              <ul id="pfdInspStreams" class="pfd-insp-list"></ul>
            </div>
          </div>
        </div>

        <!-- Bottom Stream Balance Modal / Drawer -->
        <div id="pfdStreamDrawer" class="pfd-stream-table-drawer" style="display:none;">
          <div class="pfd-std-header">
            <div class="pfd-std-title">📋 جدول موازنة المواد وتراكيب الغازات الكامل (${sheet.dwgNo})</div>
            <button id="pfdStdClose" class="pfd-std-close">إغلاق ✕</button>
          </div>
          <div class="pfd-std-content">
            ${this.renderStreamBalanceTable()}
          </div>
        </div>

        <!-- DCS CONTROLLER FACEPLATE MODAL (Yokogawa CENTUM / DeltaV Style) -->
        <div id="dcsFaceplateModal" class="dcs-faceplate-modal" style="display:none;">
          <div class="dcs-fp-container">
            <div class="dcs-fp-header">
              <div class="dcs-fp-tag-box">
                <span id="dcsFpTag" class="dcs-fp-tag">PIC-001</span>
                <span id="dcsFpMode" class="dcs-fp-mode-badge">AUTO</span>
              </div>
              <div class="dcs-fp-status">NORMAL</div>
              <button id="dcsFpClose" class="dcs-fp-close-btn">✕</button>
            </div>

            <div class="dcs-fp-body">
              <div id="dcsFpDesc" class="dcs-fp-desc">Natural Gas Pressure Controller</div>
              <div id="dcsFpDescAr" class="dcs-fp-desc-ar">متحكم ضغط مجمع استلام الغاز الطبيعي</div>

              <!-- Bar Graph Section -->
              <div class="dcs-fp-bargraphs">
                <!-- PV Bar -->
                <div class="dcs-fp-bar-col">
                  <div class="dcs-fp-bar-track">
                    <div id="dcsFpBarHH" class="dcs-fp-limit hh" style="bottom:90%;"></div>
                    <div id="dcsFpBarH" class="dcs-fp-limit h" style="bottom:80%;"></div>
                    <div id="dcsFpBarL" class="dcs-fp-limit l" style="bottom:20%;"></div>
                    <div id="dcsFpBarLL" class="dcs-fp-limit ll" style="bottom:10%;"></div>
                    <div id="dcsFpBarFillPV" class="dcs-fp-bar-fill pv" style="height:75%;"></div>
                    <div id="dcsFpSpMarker" class="dcs-fp-sp-marker" style="bottom:75%;"></div>
                  </div>
                  <div class="dcs-fp-bar-title">PV</div>
                </div>

                <!-- Digital Values -->
                <div class="dcs-fp-readouts">
                  <div class="dcs-fp-val-row">
                    <span class="dcs-fp-k">PV (متغير العملية):</span>
                    <span id="dcsFpValPV" class="dcs-fp-v pv-text">45.00</span>
                    <span id="dcsFpUnit" class="dcs-fp-unit">kg/cm²G</span>
                  </div>
                  <div class="dcs-fp-val-row">
                    <span class="dcs-fp-k">SP (القيمة المحددة):</span>
                    <div class="dcs-fp-sp-ctrl">
                      <button id="dcsFpSpDec" class="dcs-fp-btn-step">-</button>
                      <input id="dcsFpValSP" class="dcs-fp-input-sp" type="number" step="0.5" value="45.00"/>
                      <button id="dcsFpSpInc" class="dcs-fp-btn-step">+</button>
                    </div>
                  </div>
                  <div class="dcs-fp-val-row">
                    <span class="dcs-fp-k">MV (فتحة الصمام):</span>
                    <span id="dcsFpValMV" class="dcs-fp-v mv-text">62.4 %</span>
                  </div>
                  <div class="dcs-fp-val-row">
                    <span class="dcs-fp-k">الانحراف (DEV):</span>
                    <span id="dcsFpValDev" class="dcs-fp-v" style="color:#00e5aa;">0.00 %</span>
                  </div>
                </div>
              </div>

              <!-- Mode Selector -->
              <div class="dcs-fp-mode-selector">
                <button class="dcs-fp-mbtn active" data-mode="AUTO">AUTO</button>
                <button class="dcs-fp-mbtn" data-mode="MAN">MAN</button>
                <button class="dcs-fp-mbtn" data-mode="CAS">CAS</button>
              </div>

              <!-- Slider for Output % (MAN mode) -->
              <div class="dcs-fp-slider-sec">
                <div style="display:flex;justify-content:space-between;font-size:10.5px;color:#94a3b8;">
                  <span>موضع الصمام اليدوي (Manual Valve Output):</span>
                  <span id="dcsFpSliderVal">62.4%</span>
                </div>
                <input id="dcsFpMvSlider" type="range" min="0" max="100" value="62" class="dcs-fp-range"/>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;

    this.bindEvents();
    this.resetZoom();
  }

  // ==========================================
  // SHEET 2: CO2 REMOVAL (DWG 6112P-100-200-00)
  // ==========================================
  private renderCO2Removal200SVG(): string {
    const isAnim = this.showParticles ? 'pfd-pipe-anim' : '';

    return `
      <!-- BLUEPRINT DRAWING 6112P-100-200-00 GRAPHICS -->
      <g id="pfd-co2-200-layers">
        
        <!-- TITLE BLOCK / LEGEND (Bottom Right) -->
        <g transform="translate(1420, 840)">
          <rect width="470" height="210" fill="#f8fafc" stroke="#0f172a" stroke-width="1.8" rx="4"/>
          <text x="15" y="24" fill="#0284c7" font-size="13" font-weight="bold" font-family="'Cairo', sans-serif">IRAQ NO. 3 PROJECT</text>
          <text x="15" y="42" fill="#334155" font-size="11" font-family="'Cairo', sans-serif">CUSTOMER: M.O.I. IRAQ - FERTILIZER PROJECT</text>
          <text x="15" y="58" fill="#334155" font-size="11" font-family="'Cairo', sans-serif">KHOR AL-ZUBAIR PHASE-1</text>
          <text x="15" y="78" fill="#0f172a" font-size="14" font-weight="bold" font-family="'Cairo', sans-serif">AMMONIA UNIT - CO2 REMOVAL SECTION</text>
          <text x="15" y="96" fill="#0284c7" font-size="12" font-weight="bold">PROCESS FLOW DIAGRAM (CATACARB)</text>
          <line x1="0" y1="110" x2="470" y2="110" stroke="#0f172a" stroke-width="1"/>
          
          <text x="15" y="130" fill="#1e293b" font-size="10.5">ORDER NO: 563030-012</text>
          <text x="15" y="148" fill="#1e293b" font-size="10.5">DATE: 7 JAN '76</text>
          <text x="15" y="166" fill="#1e293b" font-size="10.5">DWG NO: 6112P 100-200-00</text>
          
          <!-- Symbol Legend inside Title Block -->
          <g transform="translate(260, 120)">
            <polygon points="0,7 7,0 14,7 7,14" fill="#0284c7" stroke="#0f172a" stroke-width="1"/>
            <text x="20" y="11" fill="#0f172a" font-size="9.5" font-weight="600">Stream No.</text>
            <circle cx="7" cy="30" r="7" fill="#e0f2fe" stroke="#0284c7" stroke-width="1"/>
            <text x="20" y="34" fill="#0f172a" font-size="9.5" font-weight="600">Press. kg/cm²A</text>
            <rect x="0" y="48" width="16" height="12" rx="3" fill="#fef3c7" stroke="#d97706" stroke-width="1"/>
            <text x="20" y="58" fill="#0f172a" font-size="9.5" font-weight="600">Temp. °C</text>
            <rect x="0" y="68" width="16" height="12" fill="#dcfce7" stroke="#16a34a" stroke-width="1"/>
            <text x="20" y="78" fill="#0f172a" font-size="9.5" font-weight="600">Flow kg/h</text>
          </g>
        </g>

        <!-- PIPING LINES LAYER -->
        <g id="pfd-co2-piping">
          <!-- 1. Incoming Converted Gas (Stream 1) -> E-201 -> V-201 -> T-201 -->
          <path d="M 40 430 L 370 430" fill="none" stroke="#00c8ef" stroke-width="3.5" class="${isAnim}"/>
          <path d="M 450 430 L 490 430 L 490 460 L 330 460 L 330 470" fill="none" stroke="#00c8ef" stroke-width="3" class="${isAnim}"/>
          <!-- V-201 vapor overhead to T-201 bottom (Stream 2) -->
          <path d="M 300 450 L 300 390 L 1250 390 L 1250 510 L 1280 510" fill="none" stroke="#00c8ef" stroke-width="3.5" class="${isAnim}"/>
          
          <!-- V-201 condensate to P-206 A,B and V-209 -->
          <path d="M 300 520 L 300 555" fill="none" stroke="#38bdf8" stroke-width="2"/>
          <path d="M 330 575 L 370 575 L 370 590" fill="none" stroke="#38bdf8" stroke-width="2" class="${isAnim}"/>

          <!-- 2. T-201 Bottom Rich Sol'n -> P-201 HT Turbine -> T-202 Top Flash -->
          <path d="M 1310 580 L 1310 680 L 975 680 L 975 580" fill="none" stroke="#10b981" stroke-width="3.5" class="${isAnim}"/>
          <path d="M 975 520 L 975 220 L 640 220" fill="none" stroke="#10b981" stroke-width="3.5" class="${isAnim}"/>

          <!-- 3. T-202 Semi-Lean Sol'n Draw -> P-201 A,B -> E-207 -> T-201 Mid Feed -->
          <path d="M 640 370 L 1060 370 L 1060 520" fill="none" stroke="#10b981" stroke-width="3" class="${isAnim}"/>
          <path d="M 1060 520 L 1060 330" fill="none" stroke="#10b981" stroke-width="3" class="${isAnim}"/>
          <path d="M 1060 290 L 1060 270 L 1280 270" fill="none" stroke="#10b981" stroke-width="3" class="${isAnim}"/>

          <!-- 4. T-202 Bottom Lean Sol'n -> P-202 A,B -> E-204 -> F-201 -> T-201 Top Feed -->
          <path d="M 580 580 L 580 650 L 825 650 L 825 590" fill="none" stroke="#059669" stroke-width="3.5" class="${isAnim}"/>
          <path d="M 825 535 L 825 475" fill="none" stroke="#059669" stroke-width="3.5" class="${isAnim}"/>
          <path d="M 825 430 L 825 210 L 1140 210" fill="none" stroke="#059669" stroke-width="3" class="${isAnim}"/>
          <path d="M 1190 210 L 1310 210 L 1310 160" fill="none" stroke="#059669" stroke-width="3" class="${isAnim}"/>

          <!-- 5. T-202 Reboilers Circulation: E-201 and E-202 -->
          <path d="M 540 540 L 410 540 L 410 470" fill="none" stroke="#047857" stroke-width="2.5"/>
          <path d="M 410 410 L 410 380 L 520 380" fill="none" stroke="#047857" stroke-width="2.5" class="${isAnim}"/>
          
          <path d="M 620 540 L 725 540 L 725 465" fill="none" stroke="#047857" stroke-width="2.5"/>
          <path d="M 725 410 L 725 380 L 640 380" fill="none" stroke="#047857" stroke-width="2.5" class="${isAnim}"/>

          <!-- LP Steam into E-202 -->
          <path d="M 760 435 L 800 435" fill="none" stroke="#fbbf24" stroke-width="2" stroke-dasharray="4,2"/>

          <!-- 6. T-202 Overhead Acid Gas (Stream 4) -> E-205 A,B -> V-203 -->
          <path d="M 580 120 L 580 80 L 360 80 L 360 250" fill="none" stroke="#f43f5e" stroke-width="3.5" class="${isAnim}"/>
          <path d="M 360 295 L 360 320 L 227 320 L 227 305" fill="none" stroke="#f43f5e" stroke-width="3" class="${isAnim}"/>

          <!-- 7. V-203 Top CO2 Pure Gas (Stream 5) -> Desuperheater -> To Urea Unit / ATM -->
          <path d="M 227 240 L 227 180 L 160 180" fill="none" stroke="#ef4444" stroke-width="3.5" class="${isAnim}"/>
          <path d="M 110 180 L 40 180" fill="none" stroke="#ef4444" stroke-width="3.5" class="${isAnim}" marker-end="url(#pfdArrowRed)"/>
          <path d="M 80 180 L 80 130 L 40 130" fill="none" stroke="#ef4444" stroke-width="2" stroke-dasharray="4,2" marker-end="url(#pfdArrowRed)"/>

          <!-- 8. V-203 Bottom Condensate -> P-203 A,B -> T-202 Top Reflux -->
          <path d="M 227 305 L 227 350 L 440 350" fill="none" stroke="#38bdf8" stroke-width="2.5" class="${isAnim}"/>
          <path d="M 500 350 L 540 350 L 540 170" fill="none" stroke="#38bdf8" stroke-width="2.5" class="${isAnim}"/>

          <!-- 9. T-201 Overhead Purified Gas (Stream 3) -> V-204 -> To Gas Reform / Methanation -->
          <path d="M 1310 120 L 1310 90" fill="none" stroke="#00c8ef" stroke-width="3.5"/>
          <path d="M 1340 65 L 1480 65" fill="none" stroke="#00c8ef" stroke-width="3.5" class="${isAnim}" marker-end="url(#pfdArrow)"/>

          <!-- 10. Degassing System (V-209, K-201, E-206, P-208 A,B) -->
          <!-- Air from K-201 into V-209 bottom -->
          <path d="M 340 645 L 370 645" fill="none" stroke="#94a3b8" stroke-width="2"/>
          <!-- V-209 bottom condensate to E-206 and P-208 A,B -->
          <path d="M 400 650 L 400 680 L 470 680 L 470 660" fill="none" stroke="#38bdf8" stroke-width="2"/>
          <path d="M 535 640 L 570 640" fill="none" stroke="#38bdf8" stroke-width="2" class="${isAnim}"/>
          <path d="M 630 640 L 720 640" fill="none" stroke="#38bdf8" stroke-width="2" class="${isAnim}" marker-end="url(#pfdArrow)"/>

          <!-- 11. Solvent Makeup & Sump recovery (V-205, V-207, P-204) -->
          <path d="M 175 610 L 175 670 L 210 670 L 210 655" fill="none" stroke="#059669" stroke-width="1.5"/>
          <path d="M 232 625 L 232 590 L 270 590" fill="none" stroke="#059669" stroke-width="1.5"/>

          <!-- 12. Anti-foam injection from V-206 / P-205 -->
          <path d="M 1152 625 L 1152 650 L 1085 650 L 1085 625" fill="none" stroke="#a855f7" stroke-width="1.5"/>
          <path d="M 1060 590 L 1060 560" fill="none" stroke="#a855f7" stroke-width="1.5" stroke-dasharray="3,2"/>
        </g>

        <!-- STREAM FLAGS & LABELS -->
        <g id="pfd-co2-streams">
          <!-- Stream [1]: Converted Gas from Gas Reform -->
          <g class="pfd-stream-flag" data-stream="1" transform="translate(100, 410)">
            <polygon points="0,10 12,0 24,10 12,20" fill="#0284c7" stroke="#38bdf8" stroke-width="1.5"/>
            <text x="12" y="14" fill="#ffffff" font-size="11" font-weight="bold" text-anchor="middle">1</text>
            <text x="12" y="-12" fill="#38bdf8" font-size="10" font-weight="bold" text-anchor="middle">CONV. GAS FROM GAS REF. SECT.</text>
            <!-- Process tags -->
            <rect x="-30" y="24" width="40" height="15" rx="3" fill="#0f2942" stroke="#00c8ef" stroke-width="0.8"/>
            <text x="-10" y="35" fill="#00c8ef" font-size="9" text-anchor="middle">28.9</text>
            <rect x="16" y="24" width="40" height="15" rx="3" fill="#0f2942" stroke="#fbbf24" stroke-width="0.8"/>
            <text x="36" y="35" fill="#fbbf24" font-size="9" text-anchor="middle">185 °C</text>
          </g>

          <!-- Stream [2]: Inlet Absorber -->
          <g class="pfd-stream-flag" data-stream="2" transform="translate(1190, 370)">
            <polygon points="0,10 12,0 24,10 12,20" fill="#0284c7" stroke="#38bdf8" stroke-width="1.5"/>
            <text x="12" y="14" fill="#ffffff" font-size="11" font-weight="bold" text-anchor="middle">2</text>
            <!-- Process tags -->
            <rect x="-10" y="24" width="44" height="15" rx="3" fill="#0f2942" stroke="#fbbf24" stroke-width="0.8"/>
            <text x="12" y="35" fill="#fbbf24" font-size="9" text-anchor="middle">127 °C</text>
          </g>

          <!-- Stream [3]: Exit Absorber to Gas Reform -->
          <g class="pfd-stream-flag" data-stream="3" transform="translate(1410, 45)">
            <polygon points="0,10 12,0 24,10 12,20" fill="#0284c7" stroke="#38bdf8" stroke-width="1.5"/>
            <text x="12" y="14" fill="#ffffff" font-size="11" font-weight="bold" text-anchor="middle">3</text>
            <text x="12" y="-10" fill="#00c8ef" font-size="10.5" font-weight="bold" text-anchor="middle">TO GAS REFORM SECTION</text>
            <rect x="-20" y="24" width="36" height="15" rx="3" fill="#0f2942" stroke="#00c8ef" stroke-width="0.8"/>
            <text x="-2" y="35" fill="#00c8ef" font-size="9" text-anchor="middle">28.0</text>
            <rect x="20" y="24" width="36" height="15" rx="3" fill="#0f2942" stroke="#fbbf24" stroke-width="0.8"/>
            <text x="38" y="35" fill="#fbbf24" font-size="9" text-anchor="middle">80 °C</text>
          </g>

          <!-- Stream [4]: Acid Gas Exit Regenerator -->
          <g class="pfd-stream-flag" data-stream="4" transform="translate(480, 60)">
            <polygon points="0,10 12,0 24,10 12,20" fill="#0284c7" stroke="#38bdf8" stroke-width="1.5"/>
            <text x="12" y="14" fill="#ffffff" font-size="11" font-weight="bold" text-anchor="middle">4</text>
            <rect x="-20" y="24" width="36" height="15" rx="3" fill="#0f2942" stroke="#00c8ef" stroke-width="0.8"/>
            <text x="-2" y="35" fill="#00c8ef" font-size="9" text-anchor="middle">1.46</text>
            <rect x="20" y="24" width="36" height="15" rx="3" fill="#0f2942" stroke="#fbbf24" stroke-width="0.8"/>
            <text x="38" y="35" fill="#fbbf24" font-size="9" text-anchor="middle">97 °C</text>
          </g>

          <!-- Stream [5]: Acid Gas to Urea Unit / ATM -->
          <g class="pfd-stream-flag" data-stream="5" transform="translate(80, 160)">
            <polygon points="0,10 12,0 24,10 12,20" fill="#0284c7" stroke="#38bdf8" stroke-width="1.5"/>
            <text x="12" y="14" fill="#ffffff" font-size="11" font-weight="bold" text-anchor="middle">5</text>
            <text x="12" y="-12" fill="#ef4444" font-size="10.5" font-weight="bold" text-anchor="middle">TO UREA UNIT / ATM</text>
            <rect x="-35" y="24" width="42" height="15" rx="3" fill="#0f2942" stroke="#10b981" stroke-width="0.8"/>
            <text x="-14" y="35" fill="#10b981" font-size="8.5" text-anchor="middle">61000 MAX</text>
          </g>
        </g>

        <!-- EQUIPMENT LAYER (Interactive Elements) -->
        <g id="pfd-co2-equipment" filter="url(#pfdEquipShadow)">

          <!-- 1. T-201: CO2 ABSORBER -->
          <g class="pfd-eq-item" data-tag="T-201" transform="translate(1250, 110)">
            <!-- Top Dished Head -->
            <path d="M 0 35 C 0 0, 120 0, 120 35 Z" fill="url(#pfdDishTopGrad)" stroke="#0f172a" stroke-width="2"/>
            <!-- Main Cylinder Shell -->
            <rect x="0" y="35" width="120" height="390" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2"/>
            <!-- Bottom Dished Head -->
            <path d="M 0 425 C 0 455, 120 455, 120 425 Z" fill="url(#pfdDishBotGrad)" stroke="#0f172a" stroke-width="2"/>
            <!-- Support Skirt & Base -->
            <rect x="10" y="445" width="100" height="25" fill="url(#pfdSkirtGrad)" stroke="#0f172a" stroke-width="1.8"/>
            <rect x="0" y="470" width="120" height="6" rx="2" fill="#334155" stroke="#0f172a" stroke-width="1.5"/>
            
            <!-- Internal Packed Beds (Mesh Packing) -->
            <g opacity="0.85">
              <rect x="12" y="55" width="96" height="70" rx="3" fill="#f8fafc" stroke="#475569" stroke-width="1.2"/>
              <rect x="12" y="55" width="96" height="70" fill="url(#pfdPackingPattern)"/>
              
              <rect x="12" y="145" width="96" height="70" rx="3" fill="#f8fafc" stroke="#475569" stroke-width="1.2"/>
              <rect x="12" y="145" width="96" height="70" fill="url(#pfdPackingPattern)"/>

              <rect x="12" y="235" width="96" height="70" rx="3" fill="#f8fafc" stroke="#475569" stroke-width="1.2"/>
              <rect x="12" y="235" width="96" height="70" fill="url(#pfdPackingPattern)"/>

              <rect x="12" y="325" width="96" height="70" rx="3" fill="#f8fafc" stroke="#475569" stroke-width="1.2"/>
              <rect x="12" y="325" width="96" height="70" fill="url(#pfdPackingPattern)"/>
            </g>

            <!-- Liquid Distributors -->
            <line x1="10" y1="48" x2="110" y2="48" stroke="#0284c7" stroke-width="2.5"/>
            <line x1="10" y1="228" x2="110" y2="228" stroke="#0284c7" stroke-width="2.5"/>

            <!-- Equipment Tag & Labels -->
            <rect x="5" y="485" width="110" height="26" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.8"/>
            <text x="60" y="503" fill="#0284c7" font-size="13" font-weight="bold" text-anchor="middle">T-201</text>
            <text x="60" y="525" fill="#0f172a" font-size="11" font-weight="bold" text-anchor="middle">CO2 ABSORBER</text>
            <text x="60" y="540" fill="#475569" font-size="9.5" text-anchor="middle">برج امتصاص كاتاكارب</text>
          </g>

          <!-- 2. V-204: ABSORBER KO DRUM -->
          <g class="pfd-eq-item" data-tag="V-204" transform="translate(1280, 35)">
            <path d="M 0 15 C 0 0, 60 0, 60 15 L 60 40 C 60 55, 0 55, 0 40 Z" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.8"/>
            <line x1="5" y1="26" x2="55" y2="26" stroke="#475569" stroke-dasharray="3,2"/>
            <text x="30" y="-12" fill="#0284c7" font-size="11" font-weight="bold" text-anchor="middle">V-204</text>
            <text x="30" y="-2" fill="#475569" font-size="8.5" text-anchor="middle">KO DRUM</text>
          </g>

          <!-- 3. T-202: CO2 REGENERATOR (STRIPPER) -->
          <g class="pfd-eq-item" data-tag="T-202" transform="translate(520, 110)">
            <!-- Top Dished Head -->
            <path d="M 0 35 C 0 0, 120 0, 120 35 Z" fill="url(#pfdDishTopGrad)" stroke="#0f172a" stroke-width="2"/>
            <!-- Main Cylinder Shell -->
            <rect x="0" y="35" width="120" height="390" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2"/>
            <!-- Bottom Dished Head -->
            <path d="M 0 425 C 0 455, 120 455, 120 425 Z" fill="url(#pfdDishBotGrad)" stroke="#0f172a" stroke-width="2"/>
            <!-- Support Skirt & Base -->
            <rect x="10" y="445" width="100" height="25" fill="url(#pfdSkirtGrad)" stroke="#0f172a" stroke-width="1.8"/>
            <rect x="0" y="470" width="120" height="6" rx="2" fill="#334155" stroke="#0f172a" stroke-width="1.5"/>
            
            <!-- Packed Beds -->
            <g opacity="0.85">
              <rect x="12" y="55" width="96" height="65" rx="3" fill="#f8fafc" stroke="#475569" stroke-width="1.2"/>
              <rect x="12" y="55" width="96" height="65" fill="url(#pfdPackingPattern)"/>

              <rect x="12" y="135" width="96" height="65" rx="3" fill="#f8fafc" stroke="#475569" stroke-width="1.2"/>
              <rect x="12" y="135" width="96" height="65" fill="url(#pfdPackingPattern)"/>

              <rect x="12" y="225" width="96" height="75" rx="3" fill="#f8fafc" stroke="#475569" stroke-width="1.2"/>
              <rect x="12" y="225" width="96" height="75" fill="url(#pfdPackingPattern)"/>

              <rect x="12" y="320" width="96" height="75" rx="3" fill="#f8fafc" stroke="#475569" stroke-width="1.2"/>
              <rect x="12" y="320" width="96" height="75" fill="url(#pfdPackingPattern)"/>
            </g>

            <!-- Equipment Tag & Labels -->
            <rect x="5" y="485" width="110" height="26" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.8"/>
            <text x="60" y="503" fill="#0284c7" font-size="13" font-weight="bold" text-anchor="middle">T-202</text>
            <text x="60" y="525" fill="#0f172a" font-size="11" font-weight="bold" text-anchor="middle">CO2 STRIPPER</text>
            <text x="60" y="540" fill="#475569" font-size="9.5" text-anchor="middle">برج التجريد والتنشيط</text>
          </g>

          <!-- 4. P-201 HT & P-201 A,B (Hydraulic Turbine & Semi-Lean Pump) -->
          <g class="pfd-eq-item" data-tag="P-201HT" transform="translate(935, 515)">
            <!-- Hydraulic Recovery Turbine -->
            <path d="M 0 10 L 50 20 L 50 45 L 0 55 Z" fill="url(#pfdTurbineGrad)" stroke="#0f172a" stroke-width="1.8"/>
            <rect x="10" y="55" width="30" height="8" fill="url(#pfdSkirtGrad)" stroke="#0f172a" stroke-width="1.2"/>
            <text x="25" y="76" fill="#16a34a" font-size="10" font-weight="bold" text-anchor="middle">P-201 HT</text>
            <text x="25" y="88" fill="#475569" font-size="8" text-anchor="middle">TURBINE</text>
          </g>

          <!-- Coupling -->
          <line x1="990" y1="545" x2="1015" y2="545" stroke="#0f172a" stroke-width="3" stroke-dasharray="2,2"/>

          <!-- Semi-Lean Centrifugal Pump P-201 A,B -->
          <g class="pfd-eq-item" data-tag="P-201" transform="translate(1015, 510)">
            <circle cx="35" cy="35" r="28" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2"/>
            <circle cx="35" cy="35" r="14" fill="url(#pfdMotorGrad)" stroke="#0f172a" stroke-width="1.5"/>
            <!-- Discharge Nozzle -->
            <rect x="25" y="0" width="12" height="12" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.2"/>
            <rect x="10" y="65" width="50" height="8" rx="2" fill="url(#pfdSkirtGrad)" stroke="#0f172a" stroke-width="1.2"/>
            <text x="35" y="86" fill="#0284c7" font-size="11" font-weight="bold" text-anchor="middle">P-201 A, B</text>
            <text x="35" y="98" fill="#475569" font-size="8.5" text-anchor="middle">SEMI-LEAN PUMP</text>
          </g>

          <!-- 5. E-207: SEMI-LEAN COOLER -->
          <g class="pfd-eq-item" data-tag="E-207" transform="translate(1020, 270)">
            <!-- Exchanger Shell with Channel Head -->
            <path d="M 0 10 C 0 0, 70 0, 70 10 L 70 50 C 70 60, 0 60, 0 50 Z" fill="url(#pfdExchangerShellGrad)" stroke="#0f172a" stroke-width="1.8"/>
            <line x1="8" y1="20" x2="62" y2="20" stroke="#0284c7" stroke-width="1.5" stroke-dasharray="3,2"/>
            <line x1="8" y1="30" x2="62" y2="30" stroke="#0284c7" stroke-width="1.5" stroke-dasharray="3,2"/>
            <line x1="8" y1="40" x2="62" y2="40" stroke="#0284c7" stroke-width="1.5" stroke-dasharray="3,2"/>
            <text x="35" y="-12" fill="#0284c7" font-size="11" font-weight="bold" text-anchor="middle">E-207</text>
            <text x="35" y="-2" fill="#475569" font-size="8.5" text-anchor="middle">SEMI-LEAN COOLER</text>
          </g>

          <!-- 6. P-202 A,B: LEAN SOL'N PUMP -->
          <g class="pfd-eq-item" data-tag="P-202" transform="translate(785, 525)">
            <circle cx="35" cy="35" r="26" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2"/>
            <circle cx="35" cy="35" r="12" fill="url(#pfdMotorGrad)" stroke="#0f172a" stroke-width="1.5"/>
            <rect x="10" y="62" width="50" height="8" rx="2" fill="url(#pfdSkirtGrad)" stroke="#0f172a" stroke-width="1.2"/>
            <text x="35" y="84" fill="#16a34a" font-size="11" font-weight="bold" text-anchor="middle">P-202 A, B</text>
            <text x="35" y="96" fill="#475569" font-size="8.5" text-anchor="middle">LEAN SOL'N PUMP</text>
          </g>

          <!-- 7. E-204: BFW / LEAN SOL'N EXCHANGER -->
          <g class="pfd-eq-item" data-tag="E-204" transform="translate(785, 420)">
            <path d="M 0 10 C 0 0, 70 0, 70 10 L 70 45 C 70 55, 0 55, 0 45 Z" fill="url(#pfdExchangerShellGrad)" stroke="#0f172a" stroke-width="1.8"/>
            <line x1="8" y1="20" x2="62" y2="20" stroke="#d97706" stroke-width="1.5" stroke-dasharray="3,2"/>
            <line x1="8" y1="35" x2="62" y2="35" stroke="#d97706" stroke-width="1.5" stroke-dasharray="3,2"/>
            <text x="35" y="-12" fill="#0284c7" font-size="11" font-weight="bold" text-anchor="middle">E-204</text>
            <text x="35" y="-2" fill="#475569" font-size="8.5" text-anchor="middle">BFW / LEAN EXCH</text>
          </g>

          <!-- 8. F-201: LEAN SOL'N FILTER -->
          <g class="pfd-eq-item" data-tag="F-201" transform="translate(1140, 175)">
            <path d="M 0 10 C 0 0, 50 0, 50 10 L 50 55 C 50 65, 0 65, 0 55 Z" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.8"/>
            <line x1="6" y1="32" x2="44" y2="32" stroke="#d97706" stroke-dasharray="2,2"/>
            <text x="25" y="-10" fill="#0284c7" font-size="11" font-weight="bold" text-anchor="middle">F-201</text>
            <text x="25" y="0" fill="#475569" font-size="8.5" text-anchor="middle">LEAN FILTER</text>
          </g>

          <!-- 9. E-201 & E-202 REBOILERS (Horizontal Shell & Tube with Saddles) -->
          <g class="pfd-eq-item" data-tag="E-201" transform="translate(365, 400)">
            <rect x="0" y="10" width="85" height="50" rx="6" fill="url(#pfdExchangerShellGrad)" stroke="#0f172a" stroke-width="1.8"/>
            <!-- Flanged Channel Heads -->
            <rect x="-6" y="8" width="6" height="54" rx="2" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.2"/>
            <rect x="85" y="8" width="6" height="54" rx="2" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.2"/>
            <!-- Saddles -->
            <rect x="12" y="60" width="14" height="8" fill="url(#pfdSkirtGrad)" stroke="#0f172a" stroke-width="1"/>
            <rect x="58" y="60" width="14" height="8" fill="url(#pfdSkirtGrad)" stroke="#0f172a" stroke-width="1"/>
            <!-- Tubes inside -->
            <line x1="6" y1="24" x2="78" y2="24" stroke="#0284c7" stroke-width="1.5" stroke-dasharray="3,2"/>
            <line x1="6" y1="35" x2="78" y2="35" stroke="#0284c7" stroke-width="1.5" stroke-dasharray="3,2"/>
            <line x1="6" y1="46" x2="78" y2="46" stroke="#0284c7" stroke-width="1.5" stroke-dasharray="3,2"/>
            <text x="42" y="-12" fill="#0284c7" font-size="11" font-weight="bold" text-anchor="middle">E-201</text>
            <text x="42" y="-2" fill="#475569" font-size="8.5" text-anchor="middle">CATACARB REBOILER</text>
          </g>

          <g class="pfd-eq-item" data-tag="E-202" transform="translate(680, 400)">
            <rect x="0" y="10" width="85" height="50" rx="6" fill="url(#pfdExchangerShellGrad)" stroke="#0f172a" stroke-width="1.8"/>
            <rect x="-6" y="8" width="6" height="54" rx="2" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.2"/>
            <rect x="85" y="8" width="6" height="54" rx="2" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.2"/>
            <rect x="12" y="60" width="14" height="8" fill="url(#pfdSkirtGrad)" stroke="#0f172a" stroke-width="1"/>
            <rect x="58" y="60" width="14" height="8" fill="url(#pfdSkirtGrad)" stroke="#0f172a" stroke-width="1"/>
            <line x1="6" y1="24" x2="78" y2="24" stroke="#0284c7" stroke-width="1.5" stroke-dasharray="3,2"/>
            <line x1="6" y1="35" x2="78" y2="35" stroke="#0284c7" stroke-width="1.5" stroke-dasharray="3,2"/>
            <line x1="6" y1="46" x2="78" y2="46" stroke="#0284c7" stroke-width="1.5" stroke-dasharray="3,2"/>
            <text x="42" y="-12" fill="#0284c7" font-size="11" font-weight="bold" text-anchor="middle">E-202</text>
            <text x="42" y="-2" fill="#475569" font-size="8.5" text-anchor="middle">LP STEAM REBOILER</text>
          </g>
          <!-- 11. V-201: REBOILER SEPARATOR -->
          <g class="pfd-eq-item" data-tag="V-201" transform="translate(270, 445)">
            <path d="M 0 15 C 0 0, 60 0, 60 15 L 60 55 C 60 70, 0 70, 0 55 Z" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.8"/>
            <line x1="5" y1="42" x2="55" y2="42" stroke="#0284c7" stroke-dasharray="2,2"/>
            <text x="30" y="-12" fill="#0284c7" font-size="11" font-weight="bold" text-anchor="middle">V-201</text>
            <text x="30" y="-2" fill="#475569" font-size="8.5" text-anchor="middle">REB. SEPARATOR</text>
          </g>

          <!-- 12. P-206 A,B: CONDENSATE INJECTION PUMP -->
          <g class="pfd-eq-item" data-tag="P-206" transform="translate(270, 550)">
            <circle cx="28" cy="24" r="20" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.5"/>
            <circle cx="28" cy="24" r="9" fill="url(#pfdMotorGrad)" stroke="#0f172a" stroke-width="1.2"/>
            <text x="28" y="56" fill="#0284c7" font-size="9.5" font-weight="bold" text-anchor="middle">P-206 A, B</text>
          </g>

          <!-- 13. E-205 A,B: OVERHEAD CONDENSER -->
          <g class="pfd-eq-item" data-tag="E-205" transform="translate(320, 245)">
            <rect x="0" y="8" width="80" height="42" rx="6" fill="url(#pfdExchangerShellGrad)" stroke="#0f172a" stroke-width="1.8"/>
            <line x1="6" y1="20" x2="74" y2="20" stroke="#0284c7" stroke-width="1.2" stroke-dasharray="3,2"/>
            <line x1="6" y1="32" x2="74" y2="32" stroke="#0284c7" stroke-width="1.2" stroke-dasharray="3,2"/>
            <text x="40" y="-12" fill="#0284c7" font-size="11" font-weight="bold" text-anchor="middle">E-205 A, B</text>
            <text x="40" y="-2" fill="#475569" font-size="8.5" text-anchor="middle">OVHD CONDENSER</text>
          </g>

          <!-- 14. V-203: ACID GAS SEPARATOR -->
          <g class="pfd-eq-item" data-tag="V-203" transform="translate(200, 235)">
            <path d="M 0 15 C 0 0, 55 0, 55 15 L 55 50 C 55 65, 0 65, 0 50 Z" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.8"/>
            <line x1="5" y1="38" x2="50" y2="38" stroke="#0284c7" stroke-dasharray="2,2"/>
            <text x="27" y="-12" fill="#0284c7" font-size="11" font-weight="bold" text-anchor="middle">V-203</text>
            <text x="27" y="-2" fill="#475569" font-size="8.5" text-anchor="middle">ACID GAS SEP</text>
          </g>

          <!-- 15. P-203 A,B: REFLUX PUMP -->
          <g class="pfd-eq-item" data-tag="P-203" transform="translate(440, 325)">
            <circle cx="28" cy="24" r="20" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.5"/>
            <circle cx="28" cy="24" r="9" fill="url(#pfdMotorGrad)" stroke="#0f172a" stroke-width="1.2"/>
            <text x="28" y="56" fill="#0284c7" font-size="9.5" font-weight="bold" text-anchor="middle">P-203 A, B</text>
            <text x="28" y="68" fill="#475569" font-size="8" text-anchor="middle">REFLUX PUMP</text>
          </g>

          <!-- 16. DEGASSING SECTION (V-209, K-201, E-206, P-208 A,B) -->
          <g class="pfd-eq-item" data-tag="V-209" transform="translate(370, 555)">
            <path d="M 0 15 C 0 0, 60 0, 60 15 L 60 70 C 60 85, 0 85, 0 70 Z" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.8"/>
            <rect x="8" y="20" width="44" height="42" fill="url(#pfdPackingPattern)" opacity="0.7"/>
            <text x="30" y="-10" fill="#0284c7" font-size="11" font-weight="bold" text-anchor="middle">V-209</text>
            <text x="30" y="0" fill="#475569" font-size="8.5" text-anchor="middle">DEGASSING COL</text>
          </g>

          <g class="pfd-eq-item" data-tag="K-201" transform="translate(290, 625)">
            <circle cx="25" cy="20" r="18" fill="url(#pfdTurbineGrad)" stroke="#0f172a" stroke-width="1.5"/>
            <polygon points="16,12 32,20 16,28" fill="#334155"/>
            <text x="25" y="48" fill="#0f172a" font-size="9" font-weight="bold" text-anchor="middle">K-201 BLOWER</text>
          </g>

          <g class="pfd-eq-item" data-tag="E-206" transform="translate(470, 615)">
            <circle cx="28" cy="22" r="18" fill="url(#pfdExchangerShellGrad)" stroke="#0f172a" stroke-width="1.5"/>
            <text x="28" y="52" fill="#0284c7" font-size="9" font-weight="bold" text-anchor="middle">E-206</text>
          </g>

          <g class="pfd-eq-item" data-tag="P-208" transform="translate(570, 615)">
            <circle cx="28" cy="22" r="18" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.5"/>
            <circle cx="28" cy="22" r="8" fill="url(#pfdMotorGrad)" stroke="#0f172a" stroke-width="1.2"/>
            <text x="28" y="52" fill="#0284c7" font-size="9" font-weight="bold" text-anchor="middle">P-208 A, B</text>
          </g>

          <!-- 17. STORAGE & TRANSFER (V-205, V-207, P-204, V-206, P-205) -->
          <g class="pfd-eq-item" data-tag="V-205" transform="translate(140, 535)">
            <path d="M 0 15 C 0 0, 70 0, 70 15 L 70 60 C 70 75, 0 75, 0 60 Z" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.8"/>
            <text x="35" y="42" fill="#16a34a" font-size="11" font-weight="bold" text-anchor="middle">V-205</text>
            <text x="35" y="88" fill="#475569" font-size="8.5" text-anchor="middle">CATACARB TANK</text>
          </g>

          <g class="pfd-eq-item" data-tag="V-207" transform="translate(210, 570)">
            <rect x="0" y="0" width="45" height="40" rx="4" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.2"/>
            <text x="22" y="24" fill="#16a34a" font-size="9" font-weight="bold" text-anchor="middle">V-207</text>
          </g>

          <g class="pfd-eq-item" data-tag="P-204" transform="translate(210, 620)">
            <circle cx="22" cy="16" r="14" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.2"/>
            <text x="22" y="40" fill="#16a34a" font-size="8.5" font-weight="bold" text-anchor="middle">P-204</text>
          </g>

          <g class="pfd-eq-item" data-tag="V-206" transform="translate(1130, 575)">
            <rect x="0" y="0" width="45" height="45" rx="6" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.5"/>
            <text x="22" y="26" fill="#7c3aed" font-size="9" font-weight="bold" text-anchor="middle">V-206</text>
            <text x="22" y="58" fill="#475569" font-size="8" text-anchor="middle">ANTI-FOAM</text>
          </g>

          <g class="pfd-eq-item" data-tag="P-205" transform="translate(1060, 585)">
            <circle cx="25" cy="18" r="16" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.5"/>
            <circle cx="25" cy="18" r="7" fill="url(#pfdMotorGrad)" stroke="#0f172a" stroke-width="1"/>
            <text x="25" y="44" fill="#7c3aed" font-size="8.5" font-weight="bold" text-anchor="middle">P-205 A,B</text>
          </g>
        </g>
      </g>
    `;
  }

  // ==========================================
  // SHEET 1: GAS REFORM (DWG 6112P-100-100-00)
  // ==========================================
  private renderReform100SVG(): string {
    const isAnim = this.showParticles ? 'pfd-pipe-anim' : '';

    return `
      <!-- BLUEPRINT DRAWING 6112P-100-100-00 GRAPHICS -->
      <g id="pfd-reform-100-layers">
        
        <!-- TITLE BLOCK (Bottom Right) -->
        <g transform="translate(1420, 840)">
          <rect width="470" height="210" fill="#f8fafc" stroke="#0f172a" stroke-width="1.8" rx="4"/>
          <text x="15" y="24" fill="#0284c7" font-size="13" font-weight="bold" font-family="'Cairo', sans-serif">IRAQ NO. 3 PROJECT</text>
          <text x="15" y="42" fill="#334155" font-size="11" font-family="'Cairo', sans-serif">CUSTOMER: M.O.I. IRAQ - FERTILIZER PROJECT</text>
          <text x="15" y="58" fill="#334155" font-size="11" font-family="'Cairo', sans-serif">KHOR AL-ZUBAIR PHASE-1</text>
          <text x="15" y="78" fill="#0f172a" font-size="14" font-weight="bold" font-family="'Cairo', sans-serif">AMMONIA UNIT - GAS REFORM SECTION</text>
          <text x="15" y="96" fill="#0284c7" font-size="12" font-weight="bold">PROCESS FLOW DIAGRAM</text>
          <line x1="0" y1="110" x2="470" y2="110" stroke="#0f172a" stroke-width="1"/>
          
          <text x="15" y="130" fill="#1e293b" font-size="10.5">ORDER NO: 563030-012</text>
          <text x="15" y="148" fill="#1e293b" font-size="10.5">DATE: 7 JAN '76</text>
          <text x="15" y="166" fill="#1e293b" font-size="10.5">DWG NO: 6112P 100-100-00</text>
          
          <g transform="translate(260, 120)">
            <polygon points="0,7 7,0 14,7 7,14" fill="#0284c7" stroke="#0f172a" stroke-width="1"/>
            <text x="20" y="11" fill="#0f172a" font-size="9.5" font-weight="600">Stream No.</text>
            <circle cx="7" cy="30" r="7" fill="#e0f2fe" stroke="#0284c7" stroke-width="1"/>
            <text x="20" y="34" fill="#0f172a" font-size="9.5" font-weight="600">Press. kg/cm²A</text>
            <rect x="0" y="48" width="16" height="12" rx="3" fill="#fef3c7" stroke="#d97706" stroke-width="1"/>
            <text x="20" y="58" fill="#0f172a" font-size="9.5" font-weight="600">Temp. °C</text>
          </g>
        </g>

        <!-- PIPING LINES -->
        <g id="pfd-reform-piping">
          <!-- Feed Gas -> H-101 -> R-102 A,B -->
          <path d="M 40 290 L 120 290" fill="none" stroke="#00c8ef" stroke-width="3.5" class="${isAnim}"/>
          <path d="M 210 290 L 270 290" fill="none" stroke="#00c8ef" stroke-width="3.5" class="${isAnim}"/>

          <!-- Desulfurized NG -> R-101 (Convection E-101) -->
          <path d="M 350 290 L 420 290 L 420 160 L 545 160 L 545 240" fill="none" stroke="#00c8ef" stroke-width="3" class="${isAnim}"/>
          
          <!-- Steam Mixing -> R-101 Radiant Tubes (Stream 1) -->
          <path d="M 605 255 L 680 255 L 680 230" fill="none" stroke="#00c8ef" stroke-width="3" class="${isAnim}"/>

          <!-- R-101 Radiant Outlet (Stream 2) -> Secondary Reformer R-103 -->
          <path d="M 680 500 L 680 550 L 780 550 L 780 260 L 810 260" fill="none" stroke="#ef4444" stroke-width="4" class="${isAnim}"/>

          <!-- Process Air -> E-102 -> R-103 (Stream 8) -->
          <path d="M 460 295 L 545 295" fill="none" stroke="#38bdf8" stroke-width="2.5" class="${isAnim}"/>
          <path d="M 605 295 L 855 295 L 855 240" fill="none" stroke="#38bdf8" stroke-width="2.5" class="${isAnim}"/>

          <!-- R-103 Outlet -> E-108 Reformed Gas Boiler -> HTS R-104 (Stream 3) -->
          <path d="M 855 440 L 855 480 L 995 480 L 995 330" fill="none" stroke="#ef4444" stroke-width="4" class="${isAnim}"/>
          <path d="M 1040 285 L 1090 285" fill="none" stroke="#ef4444" stroke-width="3.5" class="${isAnim}"/>

          <!-- R-104 HTS Outlet (Stream 4) -> E-109 -> E-107 -> LTS R-105 (Stream 5) -->
          <path d="M 1135 430 L 1135 470 L 1255 470 L 1255 290" fill="none" stroke="#fbbf24" stroke-width="3.5" class="${isAnim}"/>
          <path d="M 1255 290 L 1255 310" fill="none" stroke="#fbbf24" stroke-width="3.5"/>
          <path d="M 1290 335 L 1330 335 L 1330 260 L 1375 260" fill="none" stroke="#fbbf24" stroke-width="3.5" class="${isAnim}"/>

          <!-- R-105 LTS Outlet -> E-110 LP Boiler -> V-101 -> To CO2 Removal Section -->
          <path d="M 1375 430 L 1375 470 L 1495 470 L 1495 290" fill="none" stroke="#10b981" stroke-width="3.5" class="${isAnim}"/>
          <path d="M 1495 290 L 1495 320" fill="none" stroke="#10b981" stroke-width="3.5"/>
          <path d="M 1510 350 L 1570 350 L 1570 520 L 1800 520" fill="none" stroke="#10b981" stroke-width="3.5" class="${isAnim}" marker-end="url(#pfdArrowGreen)"/>

          <!-- Return from CO2 Removal (Stream 6) -> E-106 -> R-106 Methanator -->
          <path d="M 1420 180 L 1560 180 L 1560 240" fill="none" stroke="#00c8ef" stroke-width="3" class="${isAnim}"/>
          <path d="M 1630 270 L 1670 270" fill="none" stroke="#00c8ef" stroke-width="3" class="${isAnim}"/>

          <!-- R-106 Methanator Exit (Stream 7) -> E-106 -> To Syngas Compressor K-301 -->
          <path d="M 1715 430 L 1715 470 L 1595 470 L 1595 300" fill="none" stroke="#00c8ef" stroke-width="3" class="${isAnim}"/>
          <path d="M 1595 240 L 1595 120 L 1840 120" fill="none" stroke="#00c8ef" stroke-width="3.5" class="${isAnim}" marker-end="url(#pfdArrow)"/>
        </g>

        <!-- STREAM FLAGS -->
        <g id="pfd-reform-streams">
          <g class="pfd-stream-flag" data-stream="1" transform="translate(640, 210)">
            <polygon points="0,10 12,0 24,10 12,20" fill="#0284c7" stroke="#38bdf8" stroke-width="1.5"/>
            <text x="12" y="14" fill="#ffffff" font-size="11" font-weight="bold" text-anchor="middle">1</text>
            <text x="12" y="-8" fill="#38bdf8" font-size="10" font-weight="bold" text-anchor="middle">INLET R-101</text>
          </g>

          <g class="pfd-stream-flag" data-stream="2" transform="translate(730, 525)">
            <polygon points="0,10 12,0 24,10 12,20" fill="#0284c7" stroke="#38bdf8" stroke-width="1.5"/>
            <text x="12" y="14" fill="#ffffff" font-size="11" font-weight="bold" text-anchor="middle">2</text>
          </g>

          <g class="pfd-stream-flag" data-stream="3" transform="translate(1050, 260)">
            <polygon points="0,10 12,0 24,10 12,20" fill="#0284c7" stroke="#38bdf8" stroke-width="1.5"/>
            <text x="12" y="14" fill="#ffffff" font-size="11" font-weight="bold" text-anchor="middle">3</text>
          </g>

          <g class="pfd-stream-flag" data-stream="4" transform="translate(1180, 445)">
            <polygon points="0,10 12,0 24,10 12,20" fill="#0284c7" stroke="#38bdf8" stroke-width="1.5"/>
            <text x="12" y="14" fill="#ffffff" font-size="11" font-weight="bold" text-anchor="middle">4</text>
          </g>

          <g class="pfd-stream-flag" data-stream="5" transform="translate(1310, 310)">
            <polygon points="0,10 12,0 24,10 12,20" fill="#0284c7" stroke="#38bdf8" stroke-width="1.5"/>
            <text x="12" y="14" fill="#ffffff" font-size="11" font-weight="bold" text-anchor="middle">5</text>
          </g>

          <g class="pfd-stream-flag" data-stream="6" transform="translate(1480, 155)">
            <polygon points="0,10 12,0 24,10 12,20" fill="#0284c7" stroke="#38bdf8" stroke-width="1.5"/>
            <text x="12" y="14" fill="#ffffff" font-size="11" font-weight="bold" text-anchor="middle">6</text>
          </g>

          <g class="pfd-stream-flag" data-stream="7" transform="translate(1760, 95)">
            <polygon points="0,10 12,0 24,10 12,20" fill="#0284c7" stroke="#38bdf8" stroke-width="1.5"/>
            <text x="12" y="14" fill="#ffffff" font-size="11" font-weight="bold" text-anchor="middle">7</text>
          </g>

          <g class="pfd-stream-flag" data-stream="8" transform="translate(500, 270)">
            <polygon points="0,10 12,0 24,10 12,20" fill="#0284c7" stroke="#38bdf8" stroke-width="1.5"/>
            <text x="12" y="14" fill="#ffffff" font-size="11" font-weight="bold" text-anchor="middle">8</text>
            <text x="12" y="-8" fill="#38bdf8" font-size="10" font-weight="bold" text-anchor="middle">PROCESS AIR</text>
          </g>
        </g>

        <!-- EQUIPMENT LAYER -->
        <g id="pfd-reform-equipment" filter="url(#pfdEquipShadow)">
          <!-- H-101: FIRED GAS PREHEATER -->
          <g class="pfd-eq-item" data-tag="H-101" transform="translate(120, 190)">
            <!-- Top Dished Head -->
            <path d="M 0 25 C 0 0, 90 0, 90 25 Z" fill="url(#pfdDishTopGrad)" stroke="#0f172a" stroke-width="2"/>
            <!-- Cylinder Body -->
            <rect x="0" y="25" width="90" height="155" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2"/>
            <!-- Bottom Combustion Fire Hearth -->
            <rect x="5" y="145" width="80" height="35" rx="4" fill="url(#pfdFireGrad)" stroke="#dc2626" stroke-width="1.5"/>
            <!-- Serpentine Heating Coil -->
            <path d="M 15 140 L 45 40 L 75 140" fill="none" stroke="#d97706" stroke-width="2.5"/>
            <!-- Support Skirt -->
            <rect x="10" y="180" width="70" height="15" fill="url(#pfdSkirtGrad)" stroke="#0f172a" stroke-width="1.5"/>
            
            <rect x="-5" y="-30" width="100" height="24" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.8"/>
            <text x="45" y="-14" fill="#d97706" font-size="12" font-weight="bold" text-anchor="middle">H-101</text>
            <text x="45" y="210" fill="#0f172a" font-size="9" font-weight="bold" text-anchor="middle">FIRED PREHEATER</text>
          </g>

          <!-- R-102 A,B: SULFUR REMOVAL -->
          <g class="pfd-eq-item" data-tag="R-102" transform="translate(270, 210)">
            <!-- Top Dished Head -->
            <path d="M 0 30 C 0 0, 85 0, 85 30 Z" fill="url(#pfdDishTopGrad)" stroke="#0f172a" stroke-width="2"/>
            <!-- Vertical Shell -->
            <rect x="0" y="30" width="85" height="185" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2"/>
            <!-- Bottom Dished Head -->
            <path d="M 0 215 C 0 240, 85 240, 85 215 Z" fill="url(#pfdDishBotGrad)" stroke="#0f172a" stroke-width="2"/>
            <!-- Skirt -->
            <rect x="10" y="228" width="65" height="16" fill="url(#pfdSkirtGrad)" stroke="#0f172a" stroke-width="1.5"/>
            
            <!-- Catalyst Beds (Wire Mesh Packing) -->
            <rect x="10" y="45" width="65" height="60" rx="3" fill="#f8fafc" stroke="#475569" stroke-width="1.2"/>
            <rect x="10" y="45" width="65" height="60" fill="url(#pfdPackingPattern)"/>
            
            <rect x="10" y="125" width="65" height="60" rx="3" fill="#f8fafc" stroke="#475569" stroke-width="1.2"/>
            <rect x="10" y="125" width="65" height="60" fill="url(#pfdPackingPattern)"/>

            <rect x="-10" y="-30" width="105" height="24" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.8"/>
            <text x="42" y="-14" fill="#0284c7" font-size="12" font-weight="bold" text-anchor="middle">R-102 A, B</text>
            <text x="42" y="260" fill="#0f172a" font-size="9" font-weight="bold" text-anchor="middle">ZnO DESULFURIZER</text>
          </g>

          <!-- R-101: PRIMARY REFORMER -->
          <g class="pfd-eq-item" data-tag="R-101" transform="translate(520, 175)">
            <!-- Convection Section Box -->
            <rect x="15" y="30" width="85" height="230" fill="#334155" stroke="#0f172a" stroke-width="1.8"/>
            <!-- Chimney Exhaust Stack ST-101 -->
            <path d="M 48 30 L 48 0 L 68 0 L 68 30 Z" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.8"/>
            
            <!-- Convection Coils: E-101 to E-105 -->
            <g class="pfd-sub-eq" data-tag="E-101">
              <rect x="25" y="45" width="65" height="26" rx="3" fill="#ffffff" stroke="#0f172a" stroke-width="1.2"/>
              <text x="57" y="62" fill="#0284c7" font-size="9.5" font-weight="bold" text-anchor="middle">E-101</text>
            </g>
            <g class="pfd-sub-eq" data-tag="E-102">
              <rect x="25" y="80" width="65" height="26" rx="3" fill="#ffffff" stroke="#0f172a" stroke-width="1.2"/>
              <text x="57" y="97" fill="#0284c7" font-size="9.5" font-weight="bold" text-anchor="middle">E-102</text>
            </g>
            <g class="pfd-sub-eq" data-tag="E-103">
              <rect x="25" y="115" width="65" height="26" rx="3" fill="#ffffff" stroke="#0f172a" stroke-width="1.2"/>
              <text x="57" y="132" fill="#0284c7" font-size="9.5" font-weight="bold" text-anchor="middle">E-103 A,B</text>
            </g>
            <g class="pfd-sub-eq" data-tag="E-104">
              <rect x="25" y="150" width="65" height="26" rx="3" fill="#ffffff" stroke="#0f172a" stroke-width="1.2"/>
              <text x="57" y="167" fill="#0284c7" font-size="9.5" font-weight="bold" text-anchor="middle">E-104</text>
            </g>
            <g class="pfd-sub-eq" data-tag="E-105">
              <rect x="25" y="185" width="65" height="26" rx="3" fill="#ffffff" stroke="#0f172a" stroke-width="1.2"/>
              <text x="57" y="202" fill="#0284c7" font-size="9.5" font-weight="bold" text-anchor="middle">E-105 A,B</text>
            </g>

            <!-- Radiant Section Box with Glowing Fire -->
            <rect x="115" y="30" width="130" height="290" rx="4" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2"/>
            <rect x="120" y="230" width="120" height="85" rx="3" fill="url(#pfdFireGrad)" stroke="#dc2626" stroke-width="1.5"/>
            
            <!-- 288 Catalyst Tubes Lines in metallic silver -->
            <line x1="135" y1="45" x2="135" y2="295" stroke="#cbd5e1" stroke-width="3"/>
            <line x1="155" y1="45" x2="155" y2="295" stroke="#cbd5e1" stroke-width="3"/>
            <line x1="175" y1="45" x2="175" y2="295" stroke="#cbd5e1" stroke-width="3"/>
            <line x1="195" y1="45" x2="195" y2="295" stroke="#cbd5e1" stroke-width="3"/>
            <line x1="215" y1="45" x2="215" y2="295" stroke="#cbd5e1" stroke-width="3"/>
            <line x1="235" y1="45" x2="235" y2="295" stroke="#cbd5e1" stroke-width="3"/>

            <rect x="120" y="-30" width="120" height="25" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.8"/>
            <text x="180" y="-13" fill="#dc2626" font-size="13" font-weight="bold" text-anchor="middle">R-101</text>
            <text x="180" y="340" fill="#0f172a" font-size="10" font-weight="bold" text-anchor="middle">PRIMARY REFORMER (288 Tubes)</text>
          </g>

          <!-- R-103: SECONDARY REFORMER -->
          <g class="pfd-eq-item" data-tag="R-103" transform="translate(810, 205)">
            <!-- Top Dished Conical Section -->
            <path d="M 0 35 C 0 0, 95 0, 95 35 L 95 190 C 95 220, 0 220, 0 190 Z" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2"/>
            <!-- Catalyst Bed with Mesh -->
            <rect x="12" y="80" width="71" height="95" rx="3" fill="#f8fafc" stroke="#475569" stroke-width="1.2"/>
            <rect x="12" y="80" width="71" height="95" fill="url(#pfdPackingPattern)"/>
            <!-- Skirt -->
            <rect x="12" y="205" width="71" height="15" fill="url(#pfdSkirtGrad)" stroke="#0f172a" stroke-width="1.5"/>

            <rect x="-5" y="-30" width="105" height="24" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.8"/>
            <text x="47" y="-14" fill="#dc2626" font-size="12" font-weight="bold" text-anchor="middle">R-103</text>
            <text x="47" y="238" fill="#0f172a" font-size="9" font-weight="bold" text-anchor="middle">SEC. REFORMER</text>
          </g>

          <!-- E-108: REFORMED GAS W.H. BOILER -->
          <g class="pfd-eq-item" data-tag="E-108" transform="translate(950, 235)">
            <!-- Horizontal Shell with Dished Ends -->
            <rect x="0" y="8" width="95" height="60" rx="6" fill="url(#pfdExchangerShellGrad)" stroke="#0f172a" stroke-width="2"/>
            <rect x="-6" y="6" width="6" height="64" rx="2" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.2"/>
            <rect x="95" y="6" width="6" height="64" rx="2" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.2"/>
            <!-- Steam Dome -->
            <circle cx="47" cy="8" r="16" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.5"/>
            <!-- Saddles -->
            <rect x="15" y="68" width="16" height="10" fill="url(#pfdSkirtGrad)" stroke="#0f172a" stroke-width="1.2"/>
            <rect x="64" y="68" width="16" height="10" fill="url(#pfdSkirtGrad)" stroke="#0f172a" stroke-width="1.2"/>

            <rect x="-5" y="-30" width="105" height="24" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.8"/>
            <text x="47" y="-14" fill="#0284c7" font-size="12" font-weight="bold" text-anchor="middle">E-108</text>
            <text x="47" y="92" fill="#0f172a" font-size="9" font-weight="bold" text-anchor="middle">RG W.H. BOILER</text>
          </g>

          <!-- R-104: PRIMARY CO CONVERTER (HTS) -->
          <g class="pfd-eq-item" data-tag="R-104" transform="translate(1090, 205)">
            <!-- Top Dished Head -->
            <path d="M 0 30 C 0 0, 95 0, 95 30 Z" fill="url(#pfdDishTopGrad)" stroke="#0f172a" stroke-width="2"/>
            <!-- Shell -->
            <rect x="0" y="30" width="95" height="190" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2"/>
            <!-- Bottom Dished Head -->
            <path d="M 0 220 C 0 245, 95 245, 95 220 Z" fill="url(#pfdDishBotGrad)" stroke="#0f172a" stroke-width="2"/>
            <!-- Skirt -->
            <rect x="12" y="235" width="71" height="15" fill="url(#pfdSkirtGrad)" stroke="#0f172a" stroke-width="1.5"/>

            <!-- Catalyst Bed with Mesh -->
            <rect x="12" y="45" width="71" height="145" rx="3" fill="#f8fafc" stroke="#475569" stroke-width="1.2"/>
            <rect x="12" y="45" width="71" height="145" fill="url(#pfdPackingPattern)"/>

            <rect x="-5" y="-30" width="105" height="24" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.8"/>
            <text x="47" y="-14" fill="#0284c7" font-size="12" font-weight="bold" text-anchor="middle">R-104</text>
            <text x="47" y="265" fill="#0f172a" font-size="9" font-weight="bold" text-anchor="middle">HTS CONVERTER</text>
          </g>

          <!-- E-109 & E-107 Heat Exchangers -->
          <g class="pfd-eq-item" data-tag="E-109" transform="translate(1220, 220)">
            <rect x="0" y="8" width="75" height="48" rx="6" fill="url(#pfdExchangerShellGrad)" stroke="#0f172a" stroke-width="1.8"/>
            <rect x="-5" y="6" width="5" height="52" rx="2" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1"/>
            <rect x="75" y="6" width="5" height="52" rx="2" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1"/>
            <line x1="6" y1="22" x2="69" y2="22" stroke="#0284c7" stroke-width="1.2" stroke-dasharray="3,2"/>
            <line x1="6" y1="34" x2="69" y2="34" stroke="#0284c7" stroke-width="1.2" stroke-dasharray="3,2"/>
            <text x="37" y="-10" fill="#0284c7" font-size="11" font-weight="bold" text-anchor="middle">E-109</text>
          </g>

          <g class="pfd-eq-item" data-tag="E-107" transform="translate(1220, 305)">
            <rect x="0" y="8" width="75" height="44" rx="6" fill="url(#pfdExchangerShellGrad)" stroke="#0f172a" stroke-width="1.8"/>
            <line x1="6" y1="22" x2="69" y2="22" stroke="#0284c7" stroke-width="1.2" stroke-dasharray="3,2"/>
            <text x="37" y="65" fill="#0284c7" font-size="11" font-weight="bold" text-anchor="middle">E-107</text>
          </g>

          <!-- R-105: SECONDARY CO CONVERTER (LTS) -->
          <g class="pfd-eq-item" data-tag="R-105" transform="translate(1330, 205)">
            <!-- Top Dished Head -->
            <path d="M 0 30 C 0 0, 95 0, 95 30 Z" fill="url(#pfdDishTopGrad)" stroke="#0f172a" stroke-width="2"/>
            <!-- Shell -->
            <rect x="0" y="30" width="95" height="190" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2"/>
            <!-- Bottom Dished Head -->
            <path d="M 0 220 C 0 245, 95 245, 95 220 Z" fill="url(#pfdDishBotGrad)" stroke="#0f172a" stroke-width="2"/>
            <!-- Skirt -->
            <rect x="12" y="235" width="71" height="15" fill="url(#pfdSkirtGrad)" stroke="#0f172a" stroke-width="1.5"/>

            <!-- Catalyst Bed with Mesh -->
            <rect x="12" y="45" width="71" height="145" rx="3" fill="#f8fafc" stroke="#475569" stroke-width="1.2"/>
            <rect x="12" y="45" width="71" height="145" fill="url(#pfdPackingPattern)"/>

            <rect x="-5" y="-30" width="105" height="24" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.8"/>
            <text x="47" y="-14" fill="#0284c7" font-size="12" font-weight="bold" text-anchor="middle">R-105</text>
            <text x="47" y="265" fill="#0f172a" font-size="9" font-weight="bold" text-anchor="middle">LTS CONVERTER</text>
          </g>

          <!-- E-110 & V-101 -->
          <g class="pfd-eq-item" data-tag="E-110" transform="translate(1460, 220)">
            <rect x="0" y="8" width="75" height="48" rx="6" fill="url(#pfdExchangerShellGrad)" stroke="#0f172a" stroke-width="1.8"/>
            <line x1="6" y1="22" x2="69" y2="22" stroke="#0284c7" stroke-width="1.2" stroke-dasharray="3,2"/>
            <line x1="6" y1="34" x2="69" y2="34" stroke="#0284c7" stroke-width="1.2" stroke-dasharray="3,2"/>
            <text x="37" y="-10" fill="#0284c7" font-size="11" font-weight="bold" text-anchor="middle">E-110</text>
          </g>

          <g class="pfd-eq-item" data-tag="V-101" transform="translate(1470, 310)">
            <path d="M 0 15 C 0 0, 55 0, 55 15 L 55 50 C 55 65, 0 65, 0 50 Z" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.8"/>
            <line x1="5" y1="35" x2="50" y2="35" stroke="#0284c7" stroke-dasharray="2,2"/>
            <text x="27" y="75" fill="#0284c7" font-size="10" font-weight="bold" text-anchor="middle">V-101</text>
          </g>

          <!-- E-106: METHANATION HEAT EXCHANGER -->
          <g class="pfd-eq-item" data-tag="E-106" transform="translate(1560, 225)">
            <rect x="0" y="8" width="75" height="48" rx="6" fill="url(#pfdExchangerShellGrad)" stroke="#0f172a" stroke-width="1.8"/>
            <line x1="6" y1="22" x2="69" y2="22" stroke="#0284c7" stroke-width="1.2" stroke-dasharray="3,2"/>
            <line x1="6" y1="34" x2="69" y2="34" stroke="#0284c7" stroke-width="1.2" stroke-dasharray="3,2"/>
            <text x="37" y="-10" fill="#0284c7" font-size="11" font-weight="bold" text-anchor="middle">E-106</text>
            <text x="37" y="68" fill="#475569" font-size="8.5" text-anchor="middle">METH. EXCH</text>
          </g>

          <!-- R-106: METHANATOR -->
          <g class="pfd-eq-item" data-tag="R-106" transform="translate(1670, 205)">
            <!-- Top Dished Head -->
            <path d="M 0 30 C 0 0, 95 0, 95 30 Z" fill="url(#pfdDishTopGrad)" stroke="#0f172a" stroke-width="2"/>
            <!-- Shell -->
            <rect x="0" y="30" width="95" height="190" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2"/>
            <!-- Bottom Dished Head -->
            <path d="M 0 220 C 0 245, 95 245, 95 220 Z" fill="url(#pfdDishBotGrad)" stroke="#0f172a" stroke-width="2"/>
            <!-- Skirt -->
            <rect x="12" y="235" width="71" height="15" fill="url(#pfdSkirtGrad)" stroke="#0f172a" stroke-width="1.5"/>

            <!-- Catalyst Bed with Mesh -->
            <rect x="12" y="45" width="71" height="145" rx="3" fill="#f8fafc" stroke="#475569" stroke-width="1.2"/>
            <rect x="12" y="45" width="71" height="145" fill="url(#pfdPackingPattern)"/>

            <rect x="-5" y="-30" width="105" height="24" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.8"/>
            <text x="47" y="-14" fill="#0284c7" font-size="12" font-weight="bold" text-anchor="middle">R-106</text>
            <text x="47" y="265" fill="#0f172a" font-size="9" font-weight="bold" text-anchor="middle">METHANATOR</text>
          </g>
        </g>
      </g>
    `;
  }

  // ==========================================
  // STREAM BALANCE TABLE MODAL
  // ==========================================
  private renderStreamBalanceTable(): string {
    const streams = this.getStreams();
    const streamKeys = Object.keys(streams).map(Number);
    const sheet = this.getSheetInfo();

    // Check what components have values
    const hasNH3 = streamKeys.some(k => streams[k].comp.nh3 && streams[k].comp.nh3 !== '-' && streams[k].comp.nh3 !== '0');
    const hasUrea = streamKeys.some(k => streams[k].comp.urea && streams[k].comp.urea !== '-' && streams[k].comp.urea !== '0');
    const hasBiuret = streamKeys.some(k => streams[k].comp.biuret && streams[k].comp.biuret !== '-' && streams[k].comp.biuret !== '0');
    const hasInerts = streamKeys.some(k => streams[k].comp.inerts && streams[k].comp.inerts !== '-' && streams[k].comp.inerts !== '0');
    const hasAir = streamKeys.some(k => streams[k].comp.air && streams[k].comp.air !== '-' && streams[k].comp.air !== '0');
    const hasO2 = streamKeys.some(k => streams[k].comp.o2 && streams[k].comp.o2 !== '-' && streams[k].comp.o2 !== '0');
    const hasC2H6 = streamKeys.some(k => streams[k].comp.c2h6 && streams[k].comp.c2h6 !== '-' && streams[k].comp.c2h6 !== '0');
    const hasC3H8 = streamKeys.some(k => streams[k].comp.c3h8 && streams[k].comp.c3h8 !== '-' && streams[k].comp.c3h8 !== '0');
    const hasC4H10 = streamKeys.some(k => streams[k].comp.c4h10 && streams[k].comp.c4h10 !== '-' && streams[k].comp.c4h10 !== '0');
    const hasC5H12 = streamKeys.some(k => streams[k].comp.c5h12 && streams[k].comp.c5h12 !== '-' && streams[k].comp.c5h12 !== '0');
    const hasC6Plus = streamKeys.some(k => streams[k].comp.c6plus && streams[k].comp.c6plus !== '-' && streams[k].comp.c6plus !== '0');

    return `
      <table class="pfd-table">
        <thead>
          <tr>
            <th style="text-align:right;width:220px;">Stream Parameter / المكونات</th>
            ${streamKeys.map(k => `<th>[${k}]<br><span style="font-size:9px;font-weight:normal;color:#94a3b8;">${streams[k].name}</span></th>`).join('')}
          </tr>
        </thead>
        <tbody>
          <tr class="pfd-trow-highlight">
            <td style="text-align:right;font-weight:bold;">الاسم العربي للمسار</td>
            ${streamKeys.map(k => `<td style="font-size:9.5px;font-family:'Cairo',sans-serif;">${streams[k].nameAr}</td>`).join('')}
          </tr>
          <tr>
            <td style="text-align:right;">Pressure (kg/cm²A)</td>
            ${streamKeys.map(k => `<td style="color:#00c8ef;font-weight:bold;">${streams[k].pressure}</td>`).join('')}
          </tr>
          <tr>
            <td style="text-align:right;">Temperature (°C)</td>
            ${streamKeys.map(k => `<td style="color:#fbbf24;font-weight:bold;">${streams[k].temperature}</td>`).join('')}
          </tr>
          <tr>
            <td style="text-align:right;">Flow (kg/h)</td>
            ${streamKeys.map(k => `<td style="color:#10b981;font-weight:bold;">${streams[k].flowKgH || '-'}</td>`).join('')}
          </tr>
          <tr class="pfd-trow-sec">
            <td colspan="${streamKeys.length + 1}" style="text-align:right;">تراكيب الغاز والمواد (Composition Wt% / Mol%)</td>
          </tr>
          ${hasUrea ? `
          <tr>
            <td style="text-align:right;color:#10b981;font-weight:bold;">Urea (NH2-CO-NH2)</td>
            ${streamKeys.map(k => `<td style="color:#10b981;font-weight:bold;">${streams[k].comp.urea || '-'}</td>`).join('')}
          </tr>` : ''}
          ${hasBiuret ? `
          <tr>
            <td style="text-align:right;color:#ec4899;">Biuret</td>
            ${streamKeys.map(k => `<td style="color:#ec4899;">${streams[k].comp.biuret || '-'}</td>`).join('')}
          </tr>` : ''}
          ${hasInerts ? `
          <tr>
            <td style="text-align:right;color:#94a3b8;">Inerts / Passivation</td>
            ${streamKeys.map(k => `<td>${streams[k].comp.inerts || '-'}</td>`).join('')}
          </tr>` : ''}
          ${hasAir ? `
          <tr>
            <td style="text-align:right;color:#a78bfa;">Passivation Air</td>
            ${streamKeys.map(k => `<td style="color:#a78bfa;">${streams[k].comp.air || '-'}</td>`).join('')}
          </tr>` : ''}
          <tr>
            <td style="text-align:right;">CO (Carbon Monoxide)</td>
            ${streamKeys.map(k => `<td>${streams[k].comp.co || '-'}</td>`).join('')}
          </tr>
          <tr>
            <td style="text-align:right;">CO2 (Carbon Dioxide)</td>
            ${streamKeys.map(k => `<td style="font-weight:bold;color:${parseFloat(streams[k].comp.co2 || '0') > 50 ? '#ef4444' : '#38bdf8'};">${streams[k].comp.co2 || '-'}</td>`).join('')}
          </tr>
          <tr>
            <td style="text-align:right;">H2 (Hydrogen)</td>
            ${streamKeys.map(k => `<td style="color:#38bdf8;">${streams[k].comp.h2 || '-'}</td>`).join('')}
          </tr>
          <tr>
            <td style="text-align:right;">N2 (Nitrogen)</td>
            ${streamKeys.map(k => `<td>${streams[k].comp.n2 || '-'}</td>`).join('')}
          </tr>
          <tr>
            <td style="text-align:right;">Ar (Argon)</td>
            ${streamKeys.map(k => `<td>${streams[k].comp.ar || '-'}</td>`).join('')}
          </tr>
          <tr>
            <td style="text-align:right;">CH4 (Methane)</td>
            ${streamKeys.map(k => `<td>${streams[k].comp.ch4 || '-'}</td>`).join('')}
          </tr>
          ${hasNH3 ? `
          <tr>
            <td style="text-align:right;">NH3 (Ammonia)</td>
            ${streamKeys.map(k => `<td style="color:#a855f7;font-weight:bold;">${streams[k].comp.nh3 || '-'}</td>`).join('')}
          </tr>` : ''}
          ${hasO2 ? `
          <tr>
            <td style="text-align:right;">O2 (Oxygen)</td>
            ${streamKeys.map(k => `<td style="color:#ef4444;">${streams[k].comp.o2 || '-'}</td>`).join('')}
          </tr>` : ''}
          ${hasC2H6 ? `
          <tr>
            <td style="text-align:right;">C2H6 (Ethane)</td>
            ${streamKeys.map(k => `<td>${streams[k].comp.c2h6 || '-'}</td>`).join('')}
          </tr>` : ''}
          ${hasC3H8 ? `
          <tr>
            <td style="text-align:right;">C3H8 (Propane)</td>
            ${streamKeys.map(k => `<td>${streams[k].comp.c3h8 || '-'}</td>`).join('')}
          </tr>` : ''}
          ${hasC4H10 ? `
          <tr>
            <td style="text-align:right;">C4H10 (Butanes)</td>
            ${streamKeys.map(k => `<td>${streams[k].comp.c4h10 || '-'}</td>`).join('')}
          </tr>` : ''}
          ${hasC5H12 ? `
          <tr>
            <td style="text-align:right;">C5H12 (Pentanes)</td>
            ${streamKeys.map(k => `<td>${streams[k].comp.c5h12 || '-'}</td>`).join('')}
          </tr>` : ''}
          ${hasC6Plus ? `
          <tr>
            <td style="text-align:right;">C6+ (Hexane Plus)</td>
            ${streamKeys.map(k => `<td>${streams[k].comp.c6plus || '-'}</td>`).join('')}
          </tr>` : ''}
          <tr class="pfd-trow-sec">
            <td colspan="${streamKeys.length + 1}" style="text-align:right;">الموازنة الكلية والوزن الجزيئي (Total Balance & M.W.)</td>
          </tr>
          <tr>
            <td style="text-align:right;">Total Dry Gas (kg-mol/h)</td>
            ${streamKeys.map(k => `<td>${streams[k].dryGasMolH}</td>`).join('')}
          </tr>
          <tr>
            <td style="text-align:right;">H2O Steam (kg-mol/h)</td>
            ${streamKeys.map(k => `<td style="color:#38bdf8;">${streams[k].h2oMolH}</td>`).join('')}
          </tr>
          <tr>
            <td style="text-align:right;">Total Wet Gas (kg-mol/h)</td>
            ${streamKeys.map(k => `<td style="font-weight:bold;">${streams[k].wetGasMolH}</td>`).join('')}
          </tr>
          <tr>
            <td style="text-align:right;">Dry Gas Flow (t/h)</td>
            ${streamKeys.map(k => `<td>${streams[k].dryGasTh || '-'}</td>`).join('')}
          </tr>
          <tr>
            <td style="text-align:right;">Wet Gas Flow (t/h)</td>
            ${streamKeys.map(k => `<td style="color:#10b981;">${streams[k].wetGasTh || '-'}</td>`).join('')}
          </tr>
          <tr>
            <td style="text-align:right;">Dry Molecular Weight (M.W.)</td>
            ${streamKeys.map(k => `<td>${streams[k].dryMw}</td>`).join('')}
          </tr>
          <tr>
            <td style="text-align:right;">Wet Molecular Weight (M.W.)</td>
            ${streamKeys.map(k => `<td>${streams[k].wetMw}</td>`).join('')}
          </tr>
        </tbody>
      </table>
    `;
  }

  // ==========================================
  // EVENT BINDINGS & INTERACTIONS
  // ==========================================
  private bindEvents() {
    this.svgElem = document.getElementById('pfdSvg') as unknown as SVGSVGElement;
    this.zoomGroup = document.getElementById('pfdZoomGroup') as unknown as SVGGElement;
    const canvasWrapper = document.getElementById('pfdCanvasWrapper');
    if (!canvasWrapper || !this.svgElem) return;

    // Toggle DCS Sidebar Button
    const btnToggleSb = document.getElementById('pfd-btn-toggle-dcs-sidebar');
    const dcsSidebar = document.getElementById('dcsSectionSidebar');
    if (btnToggleSb && dcsSidebar) {
      btnToggleSb.addEventListener('click', () => {
        this.isDcsSidebarOpen = !this.isDcsSidebarOpen;
        dcsSidebar.classList.toggle('open', this.isDcsSidebarOpen);
      });
    }

    const btnCloseSb = document.getElementById('dcs-sb-close-btn');
    if (btnCloseSb && dcsSidebar) {
      btnCloseSb.addEventListener('click', () => {
        this.isDcsSidebarOpen = false;
        dcsSidebar.classList.remove('open');
      });
    }

    // DCS Sheet Switchers (in Sidebar)
    document.querySelectorAll('.dcs-sheet-item[data-sheet]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const sheetId = (e.currentTarget as HTMLElement).getAttribute('data-sheet') as any;
        if (sheetId) {
          this.switchSheet(sheetId);
        }
      });
    });

    // Quick Equipment Pills in Sidebar
    document.querySelectorAll('.dcs-eq-pill[data-eq]').forEach(pill => {
      pill.addEventListener('click', (e) => {
        const tag = (e.currentTarget as HTMLElement).getAttribute('data-eq');
        if (tag) this.selectEquipment(tag);
      });
    });

    // DCS PID Loop Pills in Sidebar
    document.querySelectorAll('.dcs-loop-pill[data-loop]').forEach(pill => {
      pill.addEventListener('click', (e) => {
        const tag = (e.currentTarget as HTMLElement).getAttribute('data-loop');
        if (tag) this.openFaceplate(tag);
      });
    });

    // Lock / Unlock Viewport Button
    document.getElementById('pfd-btn-lock')?.addEventListener('click', () => {
      this.toggleLock();
    });

    // Exit Button
    const btnExit = document.getElementById('pfd-btn-exit');
    if (btnExit) {
      btnExit.addEventListener('click', () => {
        if ((window as any).closeAllOverlaysAndGoHome) {
          (window as any).closeAllOverlaysAndGoHome();
        }
      });
    }

    // Zoom & Centering Buttons
    document.getElementById('pfd-btn-zoom-in')?.addEventListener('click', () => this.zoom(1.2));
    document.getElementById('pfd-btn-zoom-out')?.addEventListener('click', () => this.zoom(0.8));
    document.getElementById('pfd-btn-zoom-reset')?.addEventListener('click', () => this.resetZoom());

    // Stream Table Drawer Toggle
    const drawer = document.getElementById('pfdStreamDrawer');
    document.getElementById('pfd-btn-stream-table')?.addEventListener('click', () => {
      if (drawer) {
        drawer.style.display = drawer.style.display === 'none' ? 'flex' : 'none';
      }
    });
    document.getElementById('pfdStdClose')?.addEventListener('click', () => {
      if (drawer) drawer.style.display = 'none';
    });

    // Animation Toggle
    document.getElementById('pfd-btn-anim')?.addEventListener('click', (e) => {
      this.showParticles = !this.showParticles;
      (e.currentTarget as HTMLElement).innerHTML = `<span>⚡</span> ${this.showParticles ? 'إيقاف الحركة' : 'تشغيل الحركة'}`;
      document.querySelectorAll('.pfd-pipe-anim').forEach(el => {
        el.classList.toggle('paused', !this.showParticles);
      });
    });

    // Inspector Close
    document.getElementById('pfdInspClose')?.addEventListener('click', () => {
      const sidebar = document.getElementById('pfdInspectorSidebar');
      if (sidebar) sidebar.classList.remove('active');
      document.querySelectorAll('.pfd-eq-item').forEach(el => el.classList.remove('selected'));
    });

    // Mouse Pan & Drag with Anti-Jitter Threshold and Strict Clamping
    canvasWrapper.addEventListener('mousedown', (e: MouseEvent) => {
      if (this.isLocked) return;
      if ((e.target as HTMLElement).closest('.pfd-eq-item') || 
          (e.target as HTMLElement).closest('.pfd-stream-flag') ||
          (e.target as HTMLElement).closest('.pfd-ctrl-badge') ||
          (e.target as HTMLElement).closest('button')) {
        return;
      }
      this.isDragging = true;
      this.dragMoved = false;
      this.startMouseX = e.clientX;
      this.startMouseY = e.clientY;
      this.startDragX = e.clientX - this.panX;
      this.startDragY = e.clientY - this.panY;
    });

    window.addEventListener('mousemove', (e: MouseEvent) => {
      if (!this.isDragging || this.isLocked) return;
      const dist = Math.hypot(e.clientX - this.startMouseX, e.clientY - this.startMouseY);
      if (dist > 4) {
        this.dragMoved = true;
        this.panX = e.clientX - this.startDragX;
        this.panY = e.clientY - this.startDragY;
        this.clampPan();
        this.updateTransform();
      }
    });

    window.addEventListener('mouseup', () => {
      this.isDragging = false;
    });

    // Wheel Zoom with Clamped Boundaries
    canvasWrapper.addEventListener('wheel', (e: WheelEvent) => {
      e.preventDefault();
      const zoomFactor = e.deltaY < 0 ? 1.1 : 0.9;
      this.zoom(zoomFactor);
    });

    // Filter Buttons
    document.querySelectorAll('.pfd-ftab[data-sec]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        document.querySelectorAll('.pfd-ftab[data-sec]').forEach(b => b.classList.remove('active'));
        (e.currentTarget as HTMLElement).classList.add('active');
        const sec = (e.currentTarget as HTMLElement).getAttribute('data-sec') || 'all';
        this.filterSection(sec);
      });
    });

    // Delegate Click on Equipment & Controllers in SVG
    this.svgElem.addEventListener('click', (e: MouseEvent) => {
      if (this.dragMoved) return; // Ignore drag clicks
      const target = e.target as HTMLElement;

      // DCS Controller Tag Click
      const ctrlBadge = target.closest('.pfd-ctrl-badge') || target.closest('[data-ctrl]');
      if (ctrlBadge) {
        const ctag = ctrlBadge.getAttribute('data-ctrl') || ctrlBadge.textContent?.trim();
        if (ctag && DCS_LOOPS[ctag]) {
          this.openFaceplate(ctag);
          return;
        }
      }

      // Equipment Click
      const eqGroup = target.closest('.pfd-eq-item') || target.closest('.pfd-sub-eq') || target.closest('.pfd-eq-group');
      if (eqGroup) {
        let tag = eqGroup.getAttribute('data-tag');
        if (!tag && eqGroup.id && eqGroup.id.startsWith('eq-')) {
          tag = eqGroup.id.replace('eq-', '');
        }
        if (tag) this.selectEquipment(tag);
        return;
      }

      // Stream Flag Click
      const streamFlag = target.closest('.pfd-stream-flag') || target.closest('.pfd-stream-badge');
      if (streamFlag) {
        let sid = Number(streamFlag.getAttribute('data-stream')) || Number(streamFlag.getAttribute('data-st'));
        if (!sid && streamFlag.id && streamFlag.id.startsWith('st-flag-')) {
          sid = Number(streamFlag.id.replace('st-flag-', ''));
        }
        if (sid) this.showStreamModal(sid);
      }
    });

    // Faceplate Modal Events
    document.getElementById('dcsFpClose')?.addEventListener('click', () => {
      this.closeFaceplate();
    });

    // Faceplate SP +/- Step
    document.getElementById('dcsFpSpInc')?.addEventListener('click', () => {
      if (this.activeFaceplateTag && DCS_LOOPS[this.activeFaceplateTag]) {
        const l = DCS_LOOPS[this.activeFaceplateTag];
        l.sp = Number((l.sp + 1.0).toFixed(1));
        (document.getElementById('dcsFpValSP') as HTMLInputElement).value = l.sp.toString();
        this.updateFaceplateDisplay(l);
      }
    });

    document.getElementById('dcsFpSpDec')?.addEventListener('click', () => {
      if (this.activeFaceplateTag && DCS_LOOPS[this.activeFaceplateTag]) {
        const l = DCS_LOOPS[this.activeFaceplateTag];
        l.sp = Math.max(l.min, Number((l.sp - 1.0).toFixed(1)));
        (document.getElementById('dcsFpValSP') as HTMLInputElement).value = l.sp.toString();
        this.updateFaceplateDisplay(l);
      }
    });

    // Faceplate Mode Buttons
    document.querySelectorAll('.dcs-fp-mbtn[data-mode]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        document.querySelectorAll('.dcs-fp-mbtn[data-mode]').forEach(b => b.classList.remove('active'));
        (e.currentTarget as HTMLElement).classList.add('active');
        const mode = (e.currentTarget as HTMLElement).getAttribute('data-mode') as any;
        if (this.activeFaceplateTag && DCS_LOOPS[this.activeFaceplateTag]) {
          DCS_LOOPS[this.activeFaceplateTag].mode = mode;
          const badge = document.getElementById('dcsFpMode');
          if (badge) badge.textContent = mode;
        }
      });
    });

    // Faceplate MV Slider
    const mvSlider = document.getElementById('dcsFpMvSlider') as HTMLInputElement;
    if (mvSlider) {
      mvSlider.addEventListener('input', (e) => {
        const val = Number((e.target as HTMLInputElement).value);
        document.getElementById('dcsFpSliderVal')!.textContent = `${val}%`;
        if (this.activeFaceplateTag && DCS_LOOPS[this.activeFaceplateTag]) {
          DCS_LOOPS[this.activeFaceplateTag].mv = val;
          document.getElementById('dcsFpValMV')!.textContent = `${val.toFixed(1)} %`;
        }
      });
    }
  }

  public toggleLock() {
    this.isLocked = !this.isLocked;
    const btn = document.getElementById('pfd-btn-lock');
    const canvas = document.getElementById('pfdCanvasWrapper');
    if (btn) {
      btn.classList.toggle('dcs-btn-locked', this.isLocked);
      btn.innerHTML = `<span>${this.isLocked ? '🔒' : '🔓'}</span><span>${this.isLocked ? 'اللوحة مقفلة (ثابتة)' : 'قفل اللوحة'}</span>`;
    }
    if (canvas) {
      canvas.classList.toggle('locked-canvas', this.isLocked);
      let badge = canvas.querySelector('.dcs-canvas-lock-badge');
      if (this.isLocked && !badge) {
        const b = document.createElement('div');
        b.className = 'dcs-canvas-lock-badge';
        b.innerHTML = '<span>🔒</span> اللوحة مثبتة بالكامل ومقفلة (Canvas Locked)';
        canvas.prepend(b);
      } else if (!this.isLocked && badge) {
        badge.remove();
      }
    }
  }

  public openFaceplate(tag: string) {
    const loop = DCS_LOOPS[tag];
    if (!loop) return;
    this.activeFaceplateTag = tag;
    const modal = document.getElementById('dcsFaceplateModal');
    if (!modal) return;
    modal.style.display = 'flex';

    document.getElementById('dcsFpTag')!.textContent = loop.tag;
    document.getElementById('dcsFpMode')!.textContent = loop.mode;
    document.getElementById('dcsFpDesc')!.textContent = loop.name;
    document.getElementById('dcsFpDescAr')!.textContent = loop.nameAr;
    document.getElementById('dcsFpUnit')!.textContent = loop.unit;
    (document.getElementById('dcsFpValSP') as HTMLInputElement).value = loop.sp.toString();

    this.updateFaceplateDisplay(loop);

    if (this.faceplateInterval) clearInterval(this.faceplateInterval);
    this.faceplateInterval = setInterval(() => {
      if (!this.activeFaceplateTag) return;
      const l = DCS_LOOPS[this.activeFaceplateTag];
      if (l) {
        const noise = (Math.random() - 0.5) * (l.max - l.min) * 0.006;
        l.pv = Number((l.sp + noise).toFixed(2));
        const dev = (((l.pv - l.sp) / (l.max - l.min)) * 100).toFixed(2);
        const devElem = document.getElementById('dcsFpValDev');
        if (devElem) devElem.textContent = `${Number(dev) >= 0 ? '+' : ''}${dev} %`;
        this.updateFaceplateDisplay(l);
      }
    }, 1000);
  }

  public closeFaceplate() {
    this.activeFaceplateTag = null;
    if (this.faceplateInterval) clearInterval(this.faceplateInterval);
    const modal = document.getElementById('dcsFaceplateModal');
    if (modal) modal.style.display = 'none';
  }

  private updateFaceplateDisplay(loop: DCSControllerLoop) {
    const pvElem = document.getElementById('dcsFpValPV');
    if (pvElem) pvElem.textContent = loop.pv.toFixed(1);
    const mvElem = document.getElementById('dcsFpValMV');
    if (mvElem) mvElem.textContent = `${loop.mv.toFixed(1)} %`;

    const range = Math.max(1, loop.max - loop.min);
    const pvPct = Math.min(100, Math.max(0, ((loop.pv - loop.min) / range) * 100));
    const spPct = Math.min(100, Math.max(0, ((loop.sp - loop.min) / range) * 100));
    
    const pvBar = document.getElementById('dcsFpBarFillPV');
    if (pvBar) pvBar.style.height = `${pvPct}%`;
    const spMarker = document.getElementById('dcsFpSpMarker');
    if (spMarker) spMarker.style.bottom = `${spPct}%`;
  }

  private clampPan() {
    const maxPanX = Math.max(200, 1000 * Math.max(0.5, this.scale - 0.5));
    const maxPanY = Math.max(150, 700 * Math.max(0.5, this.scale - 0.5));
    this.panX = Math.max(-maxPanX, Math.min(maxPanX, this.panX));
    this.panY = Math.max(-maxPanY, Math.min(maxPanY, this.panY));
  }

  private filterSection(sec: string) {
    if (sec === 'all') {
      this.resetZoom();
      return;
    }

    if (this.currentSheet === 'steam_header') {
      if (sec === 's65') {
        this.panX = -200;
        this.panY = -30;
        this.scale = 1.35;
        this.selectEquipment('S-65');
      } else if (sec === 's39') {
        this.panX = -250;
        this.panY = -250;
        this.scale = 1.35;
        this.selectEquipment('S-39');
      } else if (sec === 's12') {
        this.panX = -250;
        this.panY = -450;
        this.scale = 1.35;
        this.selectEquipment('S-12');
      } else if (sec === 's3') {
        this.panX = -250;
        this.panY = -650;
        this.scale = 1.35;
        this.selectEquipment('S-3');
      }
    } else if (this.currentSheet === 'steam_bfw') {
      if (sec === 'deaeration') {
        this.panX = -200;
        this.panY = -30;
        this.scale = 1.35;
        this.selectEquipment('V-103');
      } else if (sec === 'preheating') {
        this.panX = -250;
        this.panY = -250;
        this.scale = 1.35;
        this.selectEquipment('E-105A');
      } else if (sec === 'steam_drums') {
        this.panX = -300;
        this.panY = -450;
        this.scale = 1.35;
        this.selectEquipment('V-102');
      } else if (sec === 'lp_distribution') {
        this.panX = -100;
        this.panY = -650;
        this.scale = 1.35;
        this.selectEquipment('P-104');
      }
    } else if (this.currentSheet === 'urea_500') {
      if (sec === 'co2_comp') {
        this.panX = -100;
        this.panY = -200;
        this.scale = 1.35;
        this.selectEquipment('K-501');
      } else if (sec === 'synthesis_loop') {
        this.panX = -550;
        this.panY = -50;
        this.scale = 1.35;
        this.selectEquipment('R-501');
      } else if (sec === 'mp_section') {
        this.panX = -1100;
        this.panY = -80;
        this.scale = 1.35;
        this.selectEquipment('V-502');
      } else if (sec === 'lp_section') {
        this.panX = -1500;
        this.panY = -80;
        this.scale = 1.35;
        this.selectEquipment('V-504');
      } else if (sec === 'waste_water') {
        this.panX = -1800;
        this.panY = -80;
        this.scale = 1.35;
        this.selectEquipment('T-502');
      } else if (sec === 'vacuum_evap') {
        this.panX = -2050;
        this.panY = -60;
        this.scale = 1.35;
        this.selectEquipment('E-561');
      } else if (sec === 'prilling_finishing') {
        this.panX = -2350;
        this.panY = -40;
        this.scale = 1.25;
        this.selectEquipment('T-571');
      }
    } else if (this.currentSheet === 'synth_400') {
      if (sec === 'synth_loop') {
        this.panX = -1300;
        this.panY = -120;
        this.scale = 1.35;
        this.selectEquipment('R-401');
      } else if (sec === 'chilling_sep') {
        this.panX = -350;
        this.panY = -120;
        this.scale = 1.35;
        this.selectEquipment('E-406');
      } else if (sec === 'letdown') {
        this.panX = -450;
        this.panY = -360;
        this.scale = 1.45;
        this.selectEquipment('V-409');
      } else if (sec === 'refrig_comp') {
        this.panX = -150;
        this.panY = -550;
        this.scale = 1.4;
        this.selectEquipment('K-401');
      } else if (sec === 'refrig_sep') {
        this.panX = -550;
        this.panY = -520;
        this.scale = 1.35;
        this.selectEquipment('V-405');
      } else if (sec === 'purge_rec') {
        this.panX = -1400;
        this.panY = -520;
        this.scale = 1.4;
        this.selectEquipment('E-408');
      } else if (sec === 'startup_h401') {
        this.panX = -1750;
        this.panY = -120;
        this.scale = 1.4;
        this.selectEquipment('H-401');
      }
    } else if (this.currentSheet === 'comp_300') {
      if (sec === 'k301') {
        this.panX = -80;
        this.panY = -120;
        this.scale = 1.35;
        this.selectEquipment('K-301');
      } else if (sec === 'k302') {
        this.panX = -650;
        this.panY = -200;
        this.scale = 1.35;
        this.selectEquipment('K-302');
      } else if (sec === 'k303') {
        this.panX = -1180;
        this.panY = -220;
        this.scale = 1.45;
        this.selectEquipment('K-303');
      } else if (sec === 'coolers_sep') {
        this.panX = -400;
        this.panY = -60;
        this.scale = 1.2;
        this.selectEquipment('E-301');
      }
    } else if (this.currentSheet === 'co2_200') {
      if (sec === 'absorber') {
        this.panX = -850;
        this.panY = -30;
        this.scale = 1.35;
        this.selectEquipment('T-201');
      } else if (sec === 'regenerator') {
        this.panX = -250;
        this.panY = -30;
        this.scale = 1.35;
        this.selectEquipment('T-202');
      } else if (sec === 'reboilers') {
        this.panX = -100;
        this.panY = -220;
        this.scale = 1.5;
        this.selectEquipment('E-201');
      } else if (sec === 'degasser') {
        this.panX = -100;
        this.panY = -350;
        this.scale = 1.6;
        this.selectEquipment('V-209');
      }
    } else {
      if (sec === 'reformer') {
        this.panX = -200;
        this.panY = -20;
        this.scale = 1.35;
        this.selectEquipment('R-101');
      } else if (sec === 'shift') {
        this.panX = -750;
        this.panY = -30;
        this.scale = 1.4;
        this.selectEquipment('R-104');
      } else if (sec === 'methanation') {
        this.panX = -1200;
        this.panY = -30;
        this.scale = 1.45;
        this.selectEquipment('R-106');
      }
    }
    this.clampPan();
    this.updateTransform();
  }

  public selectEquipment(tag: string) {
    this.selectedItem = tag;
    const eqList = this.getEquipment();
    const eq = eqList[tag];
    if (!eq) return;

    // Highlight in SVG
    document.querySelectorAll('.pfd-eq-item').forEach(el => {
      if (el.getAttribute('data-tag') === tag) {
        el.classList.add('selected');
      } else {
        el.classList.remove('selected');
      }
    });

    const sidebar = document.getElementById('pfdInspectorSidebar');
    if (!sidebar) return;
    sidebar.classList.add('active');

    document.getElementById('pfdInspTag')!.textContent = eq.tag;
    document.getElementById('pfdInspTitle')!.textContent = eq.name;
    document.getElementById('pfdInspNameAr')!.textContent = eq.nameAr;
    document.getElementById('pfdInspDesc')!.textContent = eq.descAr;

    const specsContainer = document.getElementById('pfdInspSpecs')!;
    let specsHtml = '';
    if (eq.duty) specsHtml += `<div class="pfd-spec-row"><span class="pfd-spec-k">الحمل الحراري (Duty Q):</span><span class="pfd-spec-v highlight">${eq.duty}</span></div>`;
    if (eq.deltaP) specsHtml += `<div class="pfd-spec-row"><span class="pfd-spec-k">هبوط الضغط (ΔP):</span><span class="pfd-spec-v">${eq.deltaP}</span></div>`;
    if (eq.tempIn) specsHtml += `<div class="pfd-spec-row"><span class="pfd-spec-k">حرارة الدخول (Temp In):</span><span class="pfd-spec-v">${eq.tempIn}</span></div>`;
    if (eq.tempOut) specsHtml += `<div class="pfd-spec-row"><span class="pfd-spec-k">حرارة الخروج (Temp Out):</span><span class="pfd-spec-v">${eq.tempOut}</span></div>`;
    if (eq.pressIn) specsHtml += `<div class="pfd-spec-row"><span class="pfd-spec-k">ضغط الدخول (Press In):</span><span class="pfd-spec-v">${eq.pressIn}</span></div>`;
    if (eq.pressOut) specsHtml += `<div class="pfd-spec-row"><span class="pfd-spec-k">ضغط الخروج (Press Out):</span><span class="pfd-spec-v">${eq.pressOut}</span></div>`;
    if (eq.catalyst) specsHtml += `<div class="pfd-spec-row"><span class="pfd-spec-k">العامل الحفاز / الحشوة:</span><span class="pfd-spec-v cat">${eq.catalyst}</span></div>`;
    specsContainer.innerHTML = specsHtml;
  }

  public showStreamModal(streamId: number) {
    const streams = this.getStreams();
    const st = streams[streamId];
    if (!st) return;

    const drawer = document.getElementById('pfdStreamDrawer');
    if (drawer) {
      drawer.style.display = 'flex';
    }
  }

  private zoom(factor: number) {
    const newScale = Math.min(Math.max(this.scale * factor, 0.45), 3.5);
    this.scale = newScale;
    this.clampPan();
    this.updateTransform();
  }

  private resetZoom() {
    this.scale = 0.95;
    this.panX = 0;
    this.panY = 0;
    this.updateTransform();
  }

  private updateTransform() {
    if (!this.zoomGroup) return;
    this.zoomGroup.setAttribute('transform', `translate(${this.panX}, ${this.panY}) scale(${this.scale})`);
  }
}

export const plantDiagram2D = new PlantDiagram2D();
