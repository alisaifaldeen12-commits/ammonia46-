/**
 * render_synth_400_svg.ts
 * Vector Blueprint Renderer for DWG NO. 6112P 300-401-00 (400A) & 6112P 300-402-00 (400B)
 * Ammonia Unit - Synthesis Loop & Refrigeration Section
 * Uncluttered & Spacious Engineering Layout on Crisp White DCS Canvas
 */

export function renderSynthesis400SVG(showParticles: boolean): string {
  const isAnim = showParticles ? 'pfd-pipe-anim' : '';

  return `
    <g id="pfd-synth-400-layers">
      
      <!-- ========================================== -->
      <!-- TITLE BLOCK / LEGEND (Bottom Right) -->
      <!-- ========================================== -->
      <g transform="translate(1820, 830)">
        <rect width="460" height="210" fill="#f8fafc" stroke="#0f172a" stroke-width="1.8" rx="4"/>
        <text x="15" y="26" fill="#0284c7" font-size="13" font-weight="bold" font-family="'Cairo', sans-serif">IRAQ NO. 3 PROJECT</text>
        <text x="15" y="44" fill="#334155" font-size="11" font-family="'Cairo', sans-serif">CUSTOMER: M.O.I. IRAQ - FERTILIZER PROJECT</text>
        <text x="15" y="62" fill="#334155" font-size="11" font-family="'Cairo', sans-serif">KHOR AL-ZUBAIR PHASE-1 (AMMONIA UNIT)</text>
        <text x="15" y="82" fill="#0f172a" font-size="14" font-weight="bold" font-family="'Cairo', sans-serif">SYNTHESIS & REFRIGERATION SECTION</text>
        <text x="15" y="100" fill="#7c3aed" font-size="12" font-weight="bold">DWG NO. 6112P 300-401-00 & 300-402-00</text>
        <line x1="0" y1="112" x2="460" y2="112" stroke="#0f172a" stroke-width="1"/>
        
        <text x="15" y="132" fill="#1e293b" font-size="10.5">ORDER NO: 563030-013</text>
        <text x="15" y="150" fill="#1e293b" font-size="10.5">DATE: 9.21.'75 | UNITS: 400A & 400B</text>
        <text x="15" y="170" fill="#0f172a" font-size="11" font-weight="bold">قسم تخليق وتثليج الأمونيا (R-401 / K-401)</text>
        
        <!-- Legend Symbols -->
        <g transform="translate(250, 122)">
          <polygon points="0,6 6,0 12,6 6,12" fill="#7c3aed" stroke="#0f172a" stroke-width="1"/>
          <text x="18" y="9" fill="#0f172a" font-size="9.5" font-weight="600">Stream No.</text>
          <circle cx="6" cy="26" r="6" fill="#e0f2fe" stroke="#0284c7" stroke-width="1"/>
          <text x="18" y="29" fill="#0f172a" font-size="9.5" font-weight="600">Press. kg/cm²</text>
          <rect x="0" y="42" width="14" height="11" rx="2" fill="#fef3c7" stroke="#d97706" stroke-width="1"/>
          <text x="18" y="51" fill="#0f172a" font-size="9.5" font-weight="600">Temp. °C</text>
          <rect x="0" y="60" width="14" height="11" fill="#dcfce7" stroke="#16a34a" stroke-width="1"/>
          <text x="18" y="69" fill="#0f172a" font-size="9.5" font-weight="600">Flow kg/h</text>
        </g>
      </g>

      <!-- ========================================== -->
      <!-- PIPING LAYER (SPACIOUS & UNCLUTTERED) -->
      <!-- ========================================== -->
      <g id="pfd-synth-piping">
        
        <!-- Syngas Feed from Compression Section K-303 (Top Flow Bus) -->
        <path d="M 40 130 L 1380 130 L 1380 230 L 1420 230" fill="none" stroke="#0284c7" stroke-width="3.5" class="${isAnim}"/>
        <path d="M 40 160 L 1350 160 L 1350 250 L 1420 250" fill="none" stroke="#0369a1" stroke-width="3" class="${isAnim}"/>
        
        <!-- Ex E-403 Tube to E-401 Tube -->
        <path d="M 1550 240 L 1650 240" fill="none" stroke="#0284c7" stroke-width="3.5" class="${isAnim}"/>
        
        <!-- Ex E-401 Tube to R-401 Top Inlet -->
        <path d="M 1780 240 L 1820 240 L 1820 120 L 1980 120 L 1980 160" fill="none" stroke="#dc2626" stroke-width="3.5" class="${isAnim}"/>
        
        <!-- Quench gas bypass lines to R-401 Beds 2 & 3 -->
        <path d="M 1820 240 L 1820 330 L 1890 330" fill="none" stroke="#0284c7" stroke-width="2" stroke-dasharray="4,3"/>
        <path d="M 1820 330 L 1820 440 L 1890 440" fill="none" stroke="#0284c7" stroke-width="2" stroke-dasharray="4,3"/>

        <!-- Stream 7: Hot R-401 Effluent Bottom Outlet -> E-401 Shell Side -->
        <path d="M 1980 540 L 1980 570 L 1715 570 L 1715 390" fill="none" stroke="#dc2626" stroke-width="4" class="${isAnim}"/>

        <!-- Stream 8: Ex E-401 Shell -> E-402 BFW Preheater -->
        <path d="M 1650 330 L 1550 330" fill="none" stroke="#ea580c" stroke-width="3.5" class="${isAnim}"/>
        
        <!-- Stream 9: Ex E-402 -> E-403 Shell Side -->
        <path d="M 1420 330 L 1320 330 L 1320 300" fill="none" stroke="#d97706" stroke-width="3.5" class="${isAnim}"/>

        <!-- Stream 10: Ex E-403 -> Water Coolers E-404A/B -->
        <path d="M 1190 280 L 1140 280 L 1140 240 L 1100 240" fill="none" stroke="#0284c7" stroke-width="3.5" class="${isAnim}"/>
        <path d="M 1140 280 L 1140 370 L 1100 370" fill="none" stroke="#0284c7" stroke-width="3.5" class="${isAnim}"/>

        <!-- Stream 11: Ex E-404A/B -> Primary Separator V-401 -->
        <path d="M 960 240 L 910 240 L 910 300 L 870 300" fill="none" stroke="#0284c7" stroke-width="3.5" class="${isAnim}"/>
        <path d="M 960 370 L 910 370 L 910 300" fill="none" stroke="#0284c7" stroke-width="3.5" class="${isAnim}"/>

        <!-- Stream 12: V-401 Bottom Liquid -> Let Down Tank V-409 -->
        <path d="M 825 430 L 825 480 L 610 480 L 610 520" fill="none" stroke="#7c3aed" stroke-width="3" class="${isAnim}"/>

        <!-- Stream 13: V-401 Overhead Vapor -> Cold Exchanger E-407 Shell -->
        <path d="M 825 210 L 825 100 L 185 100 L 185 220" fill="none" stroke="#0284c7" stroke-width="3.5" class="${isAnim}"/>

        <!-- Stream 14: E-407 -> E-405 Primary Ammonia Chiller (+8°C) -->
        <path d="M 185 390 L 185 430 L 350 430 L 350 390" fill="none" stroke="#0284c7" stroke-width="3.5" class="${isAnim}"/>

        <!-- Stream 15: E-405 -> E-406 Secondary Ammonia Chiller (-10°C) -->
        <path d="M 420 270 L 490 270" fill="none" stroke="#0284c7" stroke-width="3.5" class="${isAnim}"/>

        <!-- Stream 16: E-406 -> V-402 Secondary Separator -->
        <path d="M 620 270 L 670 270" fill="none" stroke="#2563eb" stroke-width="3.5" class="${isAnim}"/>

        <!-- Stream 17: V-402 Bottom Liquid -> Let Down Tank V-409 -->
        <path d="M 710 430 L 710 490 L 560 490 L 560 520" fill="none" stroke="#7c3aed" stroke-width="3" class="${isAnim}"/>

        <!-- Stream 18: V-402 Overhead Cold Vapor -> Cold Exchanger E-407 Tube side -> Recycle to K-303 -->
        <path d="M 710 210 L 710 80 L 135 80 L 135 220" fill="none" stroke="#0284c7" stroke-width="3.5" class="${isAnim}"/>
        <path d="M 135 390 L 135 480 L 40 480" fill="none" stroke="#0284c7" stroke-width="3.5" marker-end="url(#pfdArrow)" class="${isAnim}"/>

        <!-- Purge Gas System: E-408 Condenser, V-403 Separator, E-416 Heaters -->
        <path d="M 710 80 L 1480 80 L 1480 670" fill="none" stroke="#d97706" stroke-width="2.5" class="${isAnim}"/>
        <path d="M 1550 730 L 1630 730" fill="none" stroke="#d97706" stroke-width="2.5" class="${isAnim}"/>
        <!-- V-403 Bottom Liquid NH3 to V-409 -->
        <path d="M 1670 810 L 1670 850 L 510 850 L 510 630" fill="none" stroke="#7c3aed" stroke-width="2" class="${isAnim}"/>
        <!-- V-403 Overhead to E-416 Jackets -->
        <path d="M 1670 660 L 1670 630 L 1760 630 L 1760 670" fill="none" stroke="#d97706" stroke-width="2.5" class="${isAnim}"/>
        <path d="M 1890 730 L 2050 730" fill="none" stroke="#d97706" stroke-width="3" marker-end="url(#pfdArrowYellow)" class="${isAnim}"/>

        <!-- Flash Gas Recovery: V-409 -> E-409 -> V-404 -->
        <path d="M 640 520 L 640 470 L 760 470 L 760 520" fill="none" stroke="#d97706" stroke-width="2" class="${isAnim}"/>
        <path d="M 820 570 L 860 570" fill="none" stroke="#d97706" stroke-width="2" class="${isAnim}"/>
        <path d="M 900 640 L 900 670 L 730 670 L 730 750" fill="none" stroke="#7c3aed" stroke-width="2" class="${isAnim}"/>
        <path d="M 900 500 L 900 460 L 1020 460" fill="none" stroke="#64748b" stroke-width="2" marker-end="url(#pfdArrow)" class="${isAnim}"/>

        <!-- Flash Liquid to V-407/406/405 Suction Tower -->
        <path d="M 570 630 L 570 670 L 640 670" fill="none" stroke="#7c3aed" stroke-width="3" class="${isAnim}"/>

        <!-- Refrigeration Suction Bus to Compressor K-401 -->
        <path d="M 640 630 L 530 630 L 530 760 L 510 760" fill="none" stroke="#7c3aed" stroke-width="3" class="${isAnim}"/>
        <path d="M 640 730 L 450 730 L 450 770 L 430 770" fill="none" stroke="#7c3aed" stroke-width="3" class="${isAnim}"/>
        <path d="M 640 830 L 330 830 L 330 790" fill="none" stroke="#7c3aed" stroke-width="3" class="${isAnim}"/>

        <!-- K-401T Steam Driver -->
        <path d="M 150 670 L 150 735" fill="none" stroke="#dc2626" stroke-width="2.5" class="${isAnim}"/>
        <path d="M 150 845 L 150 890 L 80 890" fill="none" stroke="#64748b" stroke-width="2" marker-end="url(#pfdArrow)"/>
        <line x1="210" y1="790" x2="250" y2="790" stroke="#0f172a" stroke-width="5" stroke-dasharray="2,2"/>

        <!-- K-401 Discharge -> E-412 Condenser -> V-408 Receiver -->
        <path d="M 390 730 L 390 670 L 1050 670 L 1050 720" fill="none" stroke="#7c3aed" stroke-width="3.5" class="${isAnim}"/>
        <path d="M 1180 770 L 1250 770" fill="none" stroke="#7c3aed" stroke-width="3.5" class="${isAnim}"/>

        <!-- Liquid Refrigerant Return to Chillers -->
        <path d="M 1330 830 L 1330 870 L 350 870 L 350 390" fill="none" stroke="#9333ea" stroke-width="2.5" class="${isAnim}"/>
        <path d="M 490 870 L 490 390" fill="none" stroke="#9333ea" stroke-width="2.5" class="${isAnim}"/>

        <!-- Net NH3 Product to Storage Pumps P-401A/B -->
        <path d="M 690 890 L 690 930 L 820 930 L 820 890" fill="none" stroke="#7c3aed" stroke-width="3.5" class="${isAnim}"/>
        <path d="M 890 840 L 890 800 L 980 800 L 980 930 L 1400 930" fill="none" stroke="#7c3aed" stroke-width="4" marker-end="url(#pfdArrowPurple)" class="${isAnim}"/>

        <!-- Start-Up Loop H-401 -->
        <path d="M 1380 130 L 2160 130 L 2160 180" fill="none" stroke="#dc2626" stroke-width="2" stroke-dasharray="5,4"/>
        <path d="M 2230 420 L 2230 570 L 2000 570" fill="none" stroke="#dc2626" stroke-width="2" stroke-dasharray="5,4"/>
      </g>

      <!-- ========================================== -->
      <!-- EQUIPMENT GRAPHICS (ELEGANT SPACING & LIGHT STEEL) -->
      <!-- ========================================== -->
      <g id="pfd-synth-equipment" filter="url(#pfdEquipShadow)">
        
        <!-- 1. AMMONIA CONVERTER R-401 -->
        <g id="eq-R-401" class="pfd-eq-group" style="cursor:pointer;">
          <!-- Top dished head -->
          <path d="M 1890 200 C 1890 150, 2070 150, 2070 200 Z" fill="url(#pfdDishTopGrad)" stroke="#0f172a" stroke-width="2.5"/>
          <!-- Main cylindrical body -->
          <rect x="1890" y="200" width="180" height="300" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2.5"/>
          <!-- Bottom dished head -->
          <path d="M 1890 500 C 1890 550, 2070 550, 2070 500 Z" fill="url(#pfdDishBotGrad)" stroke="#0f172a" stroke-width="2.5"/>
          <!-- Skirt support -->
          <rect x="1910" y="525" width="140" height="25" fill="url(#pfdSkirtGrad)" stroke="#0f172a" stroke-width="1.8"/>
          
          <!-- Catalyst Bed 1 -->
          <rect x="1905" y="215" width="150" height="65" rx="6" fill="#fef3c7" stroke="#d97706" stroke-width="1.8"/>
          <text x="1980" y="244" fill="#b45309" font-size="12" font-weight="bold" text-anchor="middle">CATALYST BED 1</text>
          <text x="1980" y="262" fill="#78350f" font-size="9.5" font-weight="600" text-anchor="middle">Fe / K₂O / Al₂O₃ (480°C Peak)</text>
          
          <!-- Quench Line 1 / Mixer J-401 -->
          <circle cx="1980" cy="295" r="8" fill="#0284c7" stroke="#0f172a" stroke-width="1.5"/>
          <text x="1995" y="299" fill="#0369a1" font-size="9" font-weight="bold">J-401</text>

          <!-- Catalyst Bed 2 -->
          <rect x="1905" y="315" width="150" height="75" rx="6" fill="#fef3c7" stroke="#d97706" stroke-width="1.8"/>
          <text x="1980" y="350" fill="#b45309" font-size="12" font-weight="bold" text-anchor="middle">CATALYST BED 2</text>
          <text x="1980" y="368" fill="#78350f" font-size="9.5" font-weight="600" text-anchor="middle">Promoted Fe (~450°C)</text>

          <!-- Quench Line 2 -->
          <circle cx="1980" cy="405" r="8" fill="#0284c7" stroke="#0f172a" stroke-width="1.5"/>

          <!-- Catalyst Bed 3 -->
          <rect x="1905" y="420" width="150" height="75" rx="6" fill="#fef3c7" stroke="#d97706" stroke-width="1.8"/>
          <text x="1980" y="455" fill="#b45309" font-size="12" font-weight="bold" text-anchor="middle">CATALYST BED 3</text>
          <text x="1980" y="473" fill="#78350f" font-size="9.5" font-weight="600" text-anchor="middle">High Conversion (415°C)</text>

          <!-- Tag Plate -->
          <rect x="1910" y="115" width="140" height="30" rx="5" fill="#ffffff" stroke="#0f172a" stroke-width="2"/>
          <text x="1980" y="136" fill="#0284c7" font-size="14" font-weight="bold" text-anchor="middle">R-401</text>
          <text x="1980" y="105" fill="#0f172a" font-size="12" font-weight="bold" text-anchor="middle">مفاعل الأمونيا</text>
        </g>

        <!-- 2. CONVERTER EXCHANGER E-401 -->
        <g id="eq-E-401" class="pfd-eq-group" style="cursor:pointer;">
          <rect x="1650" y="210" width="130" height="190" rx="12" fill="url(#pfdExchangerShellGrad)" stroke="#0f172a" stroke-width="2"/>
          <path d="M 1670 240 L 1760 240 M 1670 275 L 1760 275 M 1670 310 L 1760 310 M 1670 345 L 1760 345 M 1670 380 L 1760 380" stroke="#0284c7" stroke-width="1.8" stroke-dasharray="4,2"/>
          <rect x="1660" y="170" width="110" height="26" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.5"/>
          <text x="1715" y="188" fill="#0284c7" font-size="13" font-weight="bold" text-anchor="middle">E-401</text>
          <text x="1715" y="158" fill="#0f172a" font-size="11" font-weight="bold" text-anchor="middle">مبادل غاز المفاعل</text>
        </g>

        <!-- 3. BOILER FEED WATER PREHEATER E-402 -->
        <g id="eq-E-402" class="pfd-eq-group" style="cursor:pointer;">
          <rect x="1420" y="220" width="130" height="180" rx="10" fill="url(#pfdExchangerShellGrad)" stroke="#0f172a" stroke-width="2"/>
          <path d="M 1440 250 L 1530 250 M 1440 285 L 1530 285 M 1440 320 L 1530 320 M 1440 355 L 1530 355" stroke="#16a34a" stroke-width="1.8" stroke-dasharray="3,3"/>
          <rect x="1430" y="180" width="110" height="26" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.5"/>
          <text x="1485" y="198" fill="#0284c7" font-size="13" font-weight="bold" text-anchor="middle">E-402</text>
          <text x="1485" y="168" fill="#0f172a" font-size="11" font-weight="bold" text-anchor="middle">مسخن مياه المراجل</text>
        </g>

        <!-- 4. FEED PREHEATER E-403 -->
        <g id="eq-E-403" class="pfd-eq-group" style="cursor:pointer;">
          <rect x="1190" y="220" width="130" height="180" rx="10" fill="url(#pfdExchangerShellGrad)" stroke="#0f172a" stroke-width="2"/>
          <path d="M 1210 250 L 1300 250 M 1210 285 L 1300 285 M 1210 320 L 1300 320 M 1210 355 L 1300 355" stroke="#0284c7" stroke-width="1.8"/>
          <rect x="1200" y="180" width="110" height="26" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.5"/>
          <text x="1255" y="198" fill="#0284c7" font-size="13" font-weight="bold" text-anchor="middle">E-403</text>
          <text x="1255" y="168" fill="#0f172a" font-size="11" font-weight="bold" text-anchor="middle">مسخن الغاز المغذي</text>
        </g>

        <!-- 5. WATER COOLED CONDENSERS E-404A/B -->
        <g id="eq-E-404A/B" class="pfd-eq-group" style="cursor:pointer;">
          <rect x="960" y="190" width="140" height="100" rx="8" fill="url(#pfdExchangerShellGrad)" stroke="#0f172a" stroke-width="2"/>
          <text x="1030" y="245" fill="#0284c7" font-size="12" font-weight="bold" text-anchor="middle">E-404A (CW)</text>
          
          <rect x="960" y="320" width="140" height="100" rx="8" fill="url(#pfdExchangerShellGrad)" stroke="#0f172a" stroke-width="2"/>
          <text x="1030" y="375" fill="#0284c7" font-size="12" font-weight="bold" text-anchor="middle">E-404B (CW)</text>

          <rect x="975" y="150" width="110" height="26" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.5"/>
          <text x="1030" y="168" fill="#0284c7" font-size="12" font-weight="bold" text-anchor="middle">E-404A/B</text>
          <text x="1030" y="138" fill="#0f172a" font-size="10.5" font-weight="bold" text-anchor="middle">المكثفات المائية</text>
        </g>

        <!-- 6. PRIMARY SEPARATOR V-401 -->
        <g id="eq-V-401" class="pfd-eq-group" style="cursor:pointer;">
          <path d="M 780 230 C 780 195, 870 195, 870 230 Z" fill="url(#pfdDishTopGrad)" stroke="#0f172a" stroke-width="2.2"/>
          <rect x="780" y="230" width="90" height="170" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2.2"/>
          <path d="M 780 400 C 780 435, 870 435, 870 400 Z" fill="url(#pfdDishBotGrad)" stroke="#0f172a" stroke-width="2.2"/>
          <line x1="785" y1="250" x2="865" y2="250" stroke="#64748b" stroke-width="3" stroke-dasharray="2,2"/>
          <rect x="785" y="360" width="80" height="40" rx="6" fill="#38bdf8" opacity="0.5"/>
          <text x="825" y="340" fill="#0f172a" font-size="10" font-weight="bold" text-anchor="middle">41°C / 213 bar</text>

          <rect x="770" y="160" width="110" height="26" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.5"/>
          <text x="825" y="178" fill="#0284c7" font-size="13" font-weight="bold" text-anchor="middle">V-401</text>
          <text x="825" y="148" fill="#0f172a" font-size="10.5" font-weight="bold" text-anchor="middle">الفاصل الأولي</text>
        </g>

        <!-- 7. COLD EXCHANGER E-407 -->
        <g id="eq-E-407" class="pfd-eq-group" style="cursor:pointer;">
          <rect x="100" y="220" width="120" height="180" rx="10" fill="url(#pfdExchangerShellGrad)" stroke="#0f172a" stroke-width="2"/>
          <path d="M 115 250 L 205 250 M 115 285 L 205 285 M 115 320 L 205 320 M 115 355 L 205 355" stroke="#2563eb" stroke-width="1.8" stroke-dasharray="4,2"/>
          <rect x="105" y="180" width="110" height="26" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.5"/>
          <text x="160" y="198" fill="#2563eb" font-size="13" font-weight="bold" text-anchor="middle">E-407</text>
          <text x="160" y="168" fill="#0f172a" font-size="11" font-weight="bold" text-anchor="middle">المبادل البارد</text>
        </g>

        <!-- 8. PRIMARY AMMONIA CHILLER E-405 (+8°C) -->
        <g id="eq-E-405" class="pfd-eq-group" style="cursor:pointer;">
          <rect x="290" y="220" width="130" height="180" rx="10" fill="url(#pfdExchangerShellGrad)" stroke="#0f172a" stroke-width="2"/>
          <path d="M 310 220 C 310 185, 400 185, 400 220" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2"/>
          <text x="355" y="208" fill="#0284c7" font-size="10" font-weight="bold" text-anchor="middle">NH₃ (+8°C)</text>
          <path d="M 305 260 L 405 260 M 305 295 L 405 295 M 305 330 L 405 330 M 305 365 L 405 365" stroke="#0284c7" stroke-width="1.8"/>

          <rect x="300" y="145" width="110" height="26" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.5"/>
          <text x="355" y="163" fill="#0284c7" font-size="13" font-weight="bold" text-anchor="middle">E-405</text>
          <text x="355" y="133" fill="#0f172a" font-size="10.5" font-weight="bold" text-anchor="middle">مبرد الأمونيا (+8°م)</text>
        </g>

        <!-- 9. SECONDARY AMMONIA CHILLER E-406 (-10°C) -->
        <g id="eq-E-406" class="pfd-eq-group" style="cursor:pointer;">
          <rect x="490" y="220" width="130" height="180" rx="10" fill="url(#pfdExchangerShellGrad)" stroke="#0f172a" stroke-width="2"/>
          <path d="M 510 220 C 510 185, 600 185, 600 220" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2"/>
          <text x="555" y="208" fill="#7c3aed" font-size="10" font-weight="bold" text-anchor="middle">NH₃ (-10°C)</text>
          <path d="M 505 260 L 605 260 M 505 295 L 605 295 M 505 330 L 605 330 M 505 365 L 605 365" stroke="#7c3aed" stroke-width="1.8"/>

          <rect x="500" y="145" width="110" height="26" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.5"/>
          <text x="555" y="163" fill="#7c3aed" font-size="13" font-weight="bold" text-anchor="middle">E-406</text>
          <text x="555" y="133" fill="#0f172a" font-size="10.5" font-weight="bold" text-anchor="middle">مبرد عميق (-10°م)</text>
        </g>

        <!-- 10. SECONDARY SEPARATOR V-402 (-3°C) -->
        <g id="eq-V-402" class="pfd-eq-group" style="cursor:pointer;">
          <path d="M 670 230 C 670 195, 760 195, 760 230 Z" fill="url(#pfdDishTopGrad)" stroke="#0f172a" stroke-width="2.2"/>
          <rect x="670" y="230" width="90" height="170" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2.2"/>
          <path d="M 670 400 C 670 435, 760 435, 760 400 Z" fill="url(#pfdDishBotGrad)" stroke="#0f172a" stroke-width="2.2"/>
          <line x1="675" y1="250" x2="755" y2="250" stroke="#64748b" stroke-width="3" stroke-dasharray="2,2"/>
          <rect x="675" y="360" width="80" height="40" rx="6" fill="#818cf8" opacity="0.5"/>
          <text x="715" y="340" fill="#0f172a" font-size="10" font-weight="bold" text-anchor="middle">-3°C / 234 bar</text>

          <rect x="660" y="160" width="110" height="26" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.5"/>
          <text x="715" y="178" fill="#7c3aed" font-size="13" font-weight="bold" text-anchor="middle">V-402</text>
          <text x="715" y="148" fill="#0f172a" font-size="10.5" font-weight="bold" text-anchor="middle">الفاصل الثانوي البارد</text>
        </g>

        <!-- 11. LET DOWN TANK V-409 -->
        <g id="eq-V-409" class="pfd-eq-group" style="cursor:pointer;">
          <path d="M 470 540 C 445 540, 445 610, 470 610 Z" fill="url(#pfdDishTopGrad)" stroke="#0f172a" stroke-width="2.2"/>
          <rect x="470" y="540" width="200" height="70" fill="url(#pfdSteelHorizGrad)" stroke="#0f172a" stroke-width="2.2"/>
          <path d="M 670 540 C 695 540, 695 610, 670 610 Z" fill="url(#pfdDishBotGrad)" stroke="#0f172a" stroke-width="2.2"/>
          <text x="570" y="580" fill="#581c87" font-size="11" font-weight="bold" text-anchor="middle">21 kg/cm²G | 13.2°C</text>

          <rect x="515" y="495" width="110" height="26" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.5"/>
          <text x="570" y="513" fill="#7c3aed" font-size="13" font-weight="bold" text-anchor="middle">V-409</text>
          <text x="570" y="483" fill="#0f172a" font-size="10.5" font-weight="bold" text-anchor="middle">خزان تخفيف الضغط</text>
        </g>

        <!-- 12. AMMONIA VENT CONDENSER E-409 -->
        <g id="eq-E-409" class="pfd-eq-group" style="cursor:pointer;">
          <rect x="710" y="520" width="100" height="110" rx="8" fill="url(#pfdExchangerShellGrad)" stroke="#0f172a" stroke-width="1.8"/>
          <text x="760" y="580" fill="#0284c7" font-size="10" font-weight="bold" text-anchor="middle">-25°C Vent</text>
          <rect x="710" y="485" width="100" height="24" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.2"/>
          <text x="760" y="502" fill="#0284c7" font-size="12" font-weight="bold" text-anchor="middle">E-409</text>
        </g>

        <!-- 13. VENT SEPARATOR V-404 -->
        <g id="eq-V-404" class="pfd-eq-group" style="cursor:pointer;">
          <path d="M 850 515 C 850 495, 935 495, 935 515 Z" fill="url(#pfdDishTopGrad)" stroke="#0f172a" stroke-width="1.8"/>
          <rect x="850" y="515" width="85" height="105" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="1.8"/>
          <path d="M 850 620 C 850 640, 935 640, 935 620 Z" fill="url(#pfdDishBotGrad)" stroke="#0f172a" stroke-width="1.8"/>
          <rect x="840" y="465" width="105" height="24" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.2"/>
          <text x="892" y="482" fill="#0284c7" font-size="12" font-weight="bold" text-anchor="middle">V-404</text>
        </g>

        <!-- 14. START UP HEATER H-401 -->
        <g id="eq-H-401" class="pfd-eq-group" style="cursor:pointer;">
          <polygon points="2140,420 2280,420 2260,260 2230,260 2230,150 2190,150 2190,260 2160,260" fill="url(#pfdFurnaceGrad)" stroke="#0f172a" stroke-width="2.2"/>
          <path d="M 2160 380 L 2260 380 M 2160 345 L 2260 345 M 2160 310 L 2260 310 M 2160 275 L 2260 275" stroke="#ef4444" stroke-width="2"/>
          <!-- Radiant flame effect inside -->
          <polygon points="2185,415 2210,360 2235,415" fill="url(#pfdFireGrad)" opacity="0.8"/>
          <rect x="2155" y="110" width="110" height="26" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.5"/>
          <text x="2210" y="128" fill="#ea580c" font-size="13" font-weight="bold" text-anchor="middle">H-401</text>
          <text x="2210" y="98" fill="#0f172a" font-size="11" font-weight="bold" text-anchor="middle">مسخن بدء التشغيل</text>
        </g>

        <!-- 15. REFRIGERATION COMPRESSOR TURBINE K-401T -->
        <g id="eq-K-401T" class="pfd-eq-group" style="cursor:pointer;">
          <polygon points="100,735 210,760 210,820 100,845" fill="url(#pfdTurbineGrad)" stroke="#0f172a" stroke-width="2.2"/>
          <rect x="105" y="695" width="100" height="26" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.5"/>
          <text x="155" y="713" fill="#dc2626" font-size="13" font-weight="bold" text-anchor="middle">K-401T</text>
          <text x="155" y="683" fill="#0f172a" font-size="10" font-weight="bold" text-anchor="middle">توربين ضاغط التبريد</text>
        </g>

        <!-- 16. REFRIGERATION COMPRESSOR K-401 -->
        <g id="eq-K-401" class="pfd-eq-group" style="cursor:pointer;">
          <polygon points="250,750 340,765 340,815 250,830" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2"/>
          <polygon points="360,740 450,755 450,825 360,840" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2"/>
          <line x1="340" y1="790" x2="360" y2="790" stroke="#0f172a" stroke-width="4"/>

          <rect x="300" y="695" width="110" height="26" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.5"/>
          <text x="355" y="713" fill="#7c3aed" font-size="13" font-weight="bold" text-anchor="middle">K-401</text>
          <text x="355" y="683" fill="#0f172a" font-size="10.5" font-weight="bold" text-anchor="middle">ضاغط تبريد الأمونيا</text>
        </g>

        <!-- 17. 3-STAGE REFRIGERATION SUCTION COLUMN (V-407 / V-406 / V-405) -->
        <g id="eq-V-405" class="pfd-eq-group" style="cursor:pointer;">
          <path d="M 640 595 C 640 570, 750 570, 750 595 Z" fill="url(#pfdDishTopGrad)" stroke="#0f172a" stroke-width="2.2"/>
          <rect x="640" y="595" width="110" height="280" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2.2"/>
          <path d="M 640 875 C 640 900, 750 900, 750 875 Z" fill="url(#pfdDishBotGrad)" stroke="#0f172a" stroke-width="2.2"/>
          
          <line x1="640" y1="680" x2="750" y2="680" stroke="#7c3aed" stroke-width="1.5" stroke-dasharray="4,2"/>
          <text x="695" y="635" fill="#0369a1" font-size="11" font-weight="bold" text-anchor="middle">V-407 (+8°C)</text>
          <text x="695" y="652" fill="#475569" font-size="9" font-weight="600" text-anchor="middle">4.6 kg/cm²G</text>

          <line x1="640" y1="780" x2="750" y2="780" stroke="#7c3aed" stroke-width="1.5" stroke-dasharray="4,2"/>
          <text x="695" y="735" fill="#581c87" font-size="11" font-weight="bold" text-anchor="middle">V-406 (-10°C)</text>
          <text x="695" y="752" fill="#475569" font-size="9" font-weight="600" text-anchor="middle">2.5 kg/cm²G</text>

          <text x="695" y="835" fill="#7c3aed" font-size="11" font-weight="bold" text-anchor="middle">V-405 (-32°C)</text>
          <text x="695" y="852" fill="#475569" font-size="9" font-weight="600" text-anchor="middle">0.1 kg/cm²G (Product)</text>

          <rect x="625" y="535" width="140" height="26" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.5"/>
          <text x="695" y="553" fill="#7c3aed" font-size="12" font-weight="bold" text-anchor="middle">V-405/406/407</text>
          <text x="695" y="523" fill="#0f172a" font-size="10.5" font-weight="bold" text-anchor="middle">برج فواصل سحب التبريد</text>
        </g>

        <!-- 18. AMMONIA PRODUCT PUMPS P-401A/B -->
        <g id="eq-P-401A/B" class="pfd-eq-group" style="cursor:pointer;">
          <circle cx="830" cy="840" r="19" fill="url(#pfdPumpGrad)" stroke="#0f172a" stroke-width="2"/>
          <polygon points="830,822 846,840 830,858" fill="#7c3aed"/>
          <text x="830" y="875" fill="#0f172a" font-size="10" font-weight="bold" text-anchor="middle">P-401A</text>

          <circle cx="880" cy="840" r="19" fill="url(#pfdPumpGrad)" stroke="#0f172a" stroke-width="2"/>
          <polygon points="880,822 896,840 880,858" fill="#7c3aed"/>
          <text x="880" y="875" fill="#0f172a" font-size="10" font-weight="bold" text-anchor="middle">P-401B</text>

          <rect x="815" y="780" width="95" height="24" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.2"/>
          <text x="862" y="797" fill="#7c3aed" font-size="12" font-weight="bold" text-anchor="middle">P-401A/B</text>
          <text x="862" y="768" fill="#0f172a" font-size="10" font-weight="bold" text-anchor="middle">مضخات المنتج</text>
        </g>

        <!-- 19. AMMONIA CONDENSER E-412 -->
        <g id="eq-E-412" class="pfd-eq-group" style="cursor:pointer;">
          <rect x="1050" y="700" width="140" height="150" rx="10" fill="url(#pfdExchangerShellGrad)" stroke="#0f172a" stroke-width="2"/>
          <path d="M 1065 735 L 1175 735 M 1065 770 L 1175 770 M 1065 805 L 1175 805" stroke="#0284c7" stroke-width="2"/>
          <text x="1120" y="835" fill="#0369a1" font-size="10" font-weight="bold" text-anchor="middle">CW 34.6°C -> 43°C</text>

          <rect x="1065" y="660" width="110" height="26" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.5"/>
          <text x="1120" y="678" fill="#0284c7" font-size="13" font-weight="bold" text-anchor="middle">E-412</text>
          <text x="1120" y="648" fill="#0f172a" font-size="10.5" font-weight="bold" text-anchor="middle">مكثف غاز التبريد</text>
        </g>

        <!-- 20. REFRIGERATION RECEIVER V-408 -->
        <g id="eq-V-408" class="pfd-eq-group" style="cursor:pointer;">
          <path d="M 1250 725 C 1225 725, 1225 795, 1250 795 Z" fill="url(#pfdDishTopGrad)" stroke="#0f172a" stroke-width="2.2"/>
          <rect x="1250" y="725" width="170" height="70" fill="url(#pfdSteelHorizGrad)" stroke="#0f172a" stroke-width="2.2"/>
          <path d="M 1420 725 C 1445 725, 1445 795, 1420 795 Z" fill="url(#pfdDishBotGrad)" stroke="#0f172a" stroke-width="2.2"/>
          <text x="1335" y="765" fill="#581c87" font-size="11" font-weight="bold" text-anchor="middle">16.5 kg/cm²G | 43°C</text>

          <rect x="1280" y="670" width="110" height="26" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.5"/>
          <text x="1335" y="688" fill="#7c3aed" font-size="13" font-weight="bold" text-anchor="middle">V-408</text>
          <text x="1335" y="658" fill="#0f172a" font-size="10.5" font-weight="bold" text-anchor="middle">مجمع سائل التبريد</text>
        </g>

        <!-- 21. PURGE CONDENSER E-408 -->
        <g id="eq-E-408" class="pfd-eq-group" style="cursor:pointer;">
          <rect x="1480" y="670" width="130" height="140" rx="10" fill="url(#pfdExchangerShellGrad)" stroke="#0f172a" stroke-width="2"/>
          <text x="1545" y="745" fill="#7c3aed" font-size="10" font-weight="bold" text-anchor="middle">-30°C NH₃ Chill</text>
          <rect x="1490" y="630" width="110" height="26" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.5"/>
          <text x="1545" y="648" fill="#7c3aed" font-size="13" font-weight="bold" text-anchor="middle">E-408</text>
          <text x="1545" y="618" fill="#0f172a" font-size="10.5" font-weight="bold" text-anchor="middle">مكثف غاز التنفيس</text>
        </g>

        <!-- 22. PURGE GAS SEPARATOR V-403 -->
        <g id="eq-V-403" class="pfd-eq-group" style="cursor:pointer;">
          <path d="M 1630 675 C 1630 655, 1715 655, 1715 675 Z" fill="url(#pfdDishTopGrad)" stroke="#0f172a" stroke-width="2"/>
          <rect x="1630" y="675" width="85" height="120" fill="url(#pfdSteelGrad)" stroke="#0f172a" stroke-width="2"/>
          <path d="M 1630 795 C 1630 815, 1715 815, 1715 795 Z" fill="url(#pfdDishBotGrad)" stroke="#0f172a" stroke-width="2"/>
          <text x="1672" y="740" fill="#7c3aed" font-size="10" font-weight="bold" text-anchor="middle">-27.8°C</text>
          <rect x="1620" y="625" width="105" height="24" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.2"/>
          <text x="1672" y="642" fill="#7c3aed" font-size="12" font-weight="bold" text-anchor="middle">V-403</text>
        </g>

        <!-- 23. PURGE GAS JACKET HEATERS E-416A/B/C -->
        <g id="eq-E-416A/B/C" class="pfd-eq-group" style="cursor:pointer;">
          <rect x="1760" y="660" width="140" height="140" rx="10" fill="url(#pfdExchangerShellGrad)" stroke="#0f172a" stroke-width="2"/>
          <rect x="1775" y="685" width="110" height="20" rx="4" fill="#fef3c7" stroke="#d97706" stroke-width="1.2"/>
          <rect x="1775" y="715" width="110" height="20" rx="4" fill="#fef3c7" stroke="#d97706" stroke-width="1.2"/>
          <rect x="1775" y="745" width="110" height="20" rx="4" fill="#fef3c7" stroke="#d97706" stroke-width="1.2"/>
          <text x="1830" y="785" fill="#b45309" font-size="10" font-weight="bold" text-anchor="middle">Steam -> +10°C</text>

          <rect x="1770" y="620" width="120" height="26" rx="4" fill="#ffffff" stroke="#0f172a" stroke-width="1.5"/>
          <text x="1830" y="638" fill="#d97706" font-size="12" font-weight="bold" text-anchor="middle">E-416A/B/C</text>
          <text x="1830" y="608" fill="#0f172a" font-size="10.5" font-weight="bold" text-anchor="middle">مسخنات غاز التنفيس</text>
        </g>

      </g>

      <!-- ========================================== -->
      <!-- STREAM FLAGS LAYER (Interactive Diamonds) -->
      <!-- ========================================== -->
      <g id="pfd-synth-stream-flags">
        
        <!-- Stream 1: Make-up Syngas -->
        <g id="st-flag-1" class="pfd-stream-flag" transform="translate(60, 130)" style="cursor:pointer;">
          <polygon points="0,10 10,0 20,10 10,20" fill="#0284c7" stroke="#0f172a" stroke-width="1.5"/>
          <text x="10" y="14" fill="#ffffff" font-size="10" font-weight="bold" text-anchor="middle">1</text>
        </g>

        <!-- Stream 2: Recycle Gas -->
        <g id="st-flag-2" class="pfd-stream-flag" transform="translate(60, 160)" style="cursor:pointer;">
          <polygon points="0,10 10,0 20,10 10,20" fill="#0284c7" stroke="#0f172a" stroke-width="1.5"/>
          <text x="10" y="14" fill="#ffffff" font-size="10" font-weight="bold" text-anchor="middle">2</text>
        </g>

        <!-- Stream 3: Mixed Feed -->
        <g id="st-flag-3" class="pfd-stream-flag" transform="translate(1360, 220)" style="cursor:pointer;">
          <polygon points="0,10 10,0 20,10 10,20" fill="#0284c7" stroke="#0f172a" stroke-width="1.5"/>
          <text x="10" y="14" fill="#ffffff" font-size="10" font-weight="bold" text-anchor="middle">3</text>
        </g>

        <!-- Stream 4: Preheated to E-401 -->
        <g id="st-flag-4" class="pfd-stream-flag" transform="translate(1600, 230)" style="cursor:pointer;">
          <polygon points="0,10 10,0 20,10 10,20" fill="#0284c7" stroke="#0f172a" stroke-width="1.5"/>
          <text x="10" y="14" fill="#ffffff" font-size="10" font-weight="bold" text-anchor="middle">4</text>
        </g>

        <!-- Stream 5: R-401 Top Feed -->
        <g id="st-flag-5" class="pfd-stream-flag" transform="translate(1965, 100)" style="cursor:pointer;">
          <polygon points="0,10 10,0 20,10 10,20" fill="#dc2626" stroke="#0f172a" stroke-width="1.5"/>
          <text x="10" y="14" fill="#ffffff" font-size="10" font-weight="bold" text-anchor="middle">5</text>
        </g>

        <!-- Stream 7: Hot R-401 Effluent -->
        <g id="st-flag-7" class="pfd-stream-flag" transform="translate(1820, 560)" style="cursor:pointer;">
          <polygon points="0,10 10,0 20,10 10,20" fill="#dc2626" stroke="#0f172a" stroke-width="1.5"/>
          <text x="10" y="14" fill="#ffffff" font-size="10" font-weight="bold" text-anchor="middle">7</text>
        </g>

        <!-- Stream 8: Ex E-401 to E-402 -->
        <g id="st-flag-8" class="pfd-stream-flag" transform="translate(1600, 320)" style="cursor:pointer;">
          <polygon points="0,10 10,0 20,10 10,20" fill="#ea580c" stroke="#0f172a" stroke-width="1.5"/>
          <text x="10" y="14" fill="#ffffff" font-size="10" font-weight="bold" text-anchor="middle">8</text>
        </g>

        <!-- Stream 9: Ex E-402 to E-403 -->
        <g id="st-flag-9" class="pfd-stream-flag" transform="translate(1370, 320)" style="cursor:pointer;">
          <polygon points="0,10 10,0 20,10 10,20" fill="#d97706" stroke="#0f172a" stroke-width="1.5"/>
          <text x="10" y="14" fill="#ffffff" font-size="10" font-weight="bold" text-anchor="middle">9</text>
        </g>

        <!-- Stream 10: Ex E-403 to E-404 -->
        <g id="st-flag-10" class="pfd-stream-flag" transform="translate(1140, 260)" style="cursor:pointer;">
          <polygon points="0,10 10,0 20,10 10,20" fill="#0284c7" stroke="#0f172a" stroke-width="1.5"/>
          <text x="10" y="14" fill="#ffffff" font-size="9" font-weight="bold" text-anchor="middle">10</text>
        </g>

        <!-- Stream 11: Mixture to V-401 -->
        <g id="st-flag-11" class="pfd-stream-flag" transform="translate(900, 290)" style="cursor:pointer;">
          <polygon points="0,10 10,0 20,10 10,20" fill="#0284c7" stroke="#0f172a" stroke-width="1.5"/>
          <text x="10" y="14" fill="#ffffff" font-size="9" font-weight="bold" text-anchor="middle">11</text>
        </g>

        <!-- Stream 12: Primary Liquid NH3 -->
        <g id="st-flag-12" class="pfd-stream-flag" transform="translate(730, 470)" style="cursor:pointer;">
          <polygon points="0,10 10,0 20,10 10,20" fill="#7c3aed" stroke="#0f172a" stroke-width="1.5"/>
          <text x="10" y="14" fill="#ffffff" font-size="9" font-weight="bold" text-anchor="middle">12</text>
        </g>

        <!-- Stream 13: V-401 Overhead Vapor -->
        <g id="st-flag-13" class="pfd-stream-flag" transform="translate(500, 90)" style="cursor:pointer;">
          <polygon points="0,10 10,0 20,10 10,20" fill="#0284c7" stroke="#0f172a" stroke-width="1.5"/>
          <text x="10" y="14" fill="#ffffff" font-size="9" font-weight="bold" text-anchor="middle">13</text>
        </g>

        <!-- Stream 14: To E-405 Chiller -->
        <g id="st-flag-14" class="pfd-stream-flag" transform="translate(250, 420)" style="cursor:pointer;">
          <polygon points="0,10 10,0 20,10 10,20" fill="#0284c7" stroke="#0f172a" stroke-width="1.5"/>
          <text x="10" y="14" fill="#ffffff" font-size="9" font-weight="bold" text-anchor="middle">14</text>
        </g>

        <!-- Stream 15: To E-406 Chiller -->
        <g id="st-flag-15" class="pfd-stream-flag" transform="translate(450, 260)" style="cursor:pointer;">
          <polygon points="0,10 10,0 20,10 10,20" fill="#0284c7" stroke="#0f172a" stroke-width="1.5"/>
          <text x="10" y="14" fill="#ffffff" font-size="9" font-weight="bold" text-anchor="middle">15</text>
        </g>

        <!-- Stream 16: To V-402 Separator -->
        <g id="st-flag-16" class="pfd-stream-flag" transform="translate(635, 260)" style="cursor:pointer;">
          <polygon points="0,10 10,0 20,10 10,20" fill="#2563eb" stroke="#0f172a" stroke-width="1.5"/>
          <text x="10" y="14" fill="#ffffff" font-size="9" font-weight="bold" text-anchor="middle">16</text>
        </g>

        <!-- Stream 17: Secondary Liquid NH3 -->
        <g id="st-flag-17" class="pfd-stream-flag" transform="translate(630, 480)" style="cursor:pointer;">
          <polygon points="0,10 10,0 20,10 10,20" fill="#7c3aed" stroke="#0f172a" stroke-width="1.5"/>
          <text x="10" y="14" fill="#ffffff" font-size="9" font-weight="bold" text-anchor="middle">17</text>
        </g>

        <!-- Stream 18: Cold Recycle Return -->
        <g id="st-flag-18" class="pfd-stream-flag" transform="translate(80, 470)" style="cursor:pointer;">
          <polygon points="0,10 10,0 20,10 10,20" fill="#0284c7" stroke="#0f172a" stroke-width="1.5"/>
          <text x="10" y="14" fill="#ffffff" font-size="9" font-weight="bold" text-anchor="middle">18</text>
        </g>

        <!-- Stream 19: Purge Gas Loop -->
        <g id="st-flag-19" class="pfd-stream-flag" transform="translate(1100, 70)" style="cursor:pointer;">
          <polygon points="0,10 10,0 20,10 10,20" fill="#d97706" stroke="#0f172a" stroke-width="1.5"/>
          <text x="10" y="14" fill="#ffffff" font-size="9" font-weight="bold" text-anchor="middle">19</text>
        </g>

        <!-- Stream 28: Flash Liquid to V-407 -->
        <g id="st-flag-28" class="pfd-stream-flag" transform="translate(590, 660)" style="cursor:pointer;">
          <polygon points="0,10 10,0 20,10 10,20" fill="#7c3aed" stroke="#0f172a" stroke-width="1.5"/>
          <text x="10" y="14" fill="#ffffff" font-size="9" font-weight="bold" text-anchor="middle">28</text>
        </g>

        <!-- Stream 30: Liquid NH3 ex E-412 -->
        <g id="st-flag-30" class="pfd-stream-flag" transform="translate(1210, 760)" style="cursor:pointer;">
          <polygon points="0,10 10,0 20,10 10,20" fill="#7c3aed" stroke="#0f172a" stroke-width="1.5"/>
          <text x="10" y="14" fill="#ffffff" font-size="9" font-weight="bold" text-anchor="middle">30</text>
        </g>

        <!-- Stream 32: Net NH3 Product to Storage -->
        <g id="st-flag-32" class="pfd-stream-flag" transform="translate(1220, 920)" style="cursor:pointer;">
          <polygon points="0,12 12,0 24,12 12,24" fill="#7c3aed" stroke="#0f172a" stroke-width="2"/>
          <text x="12" y="16" fill="#ffffff" font-size="11" font-weight="bold" text-anchor="middle">32</text>
        </g>

      </g>

    </g>
  `;
}
